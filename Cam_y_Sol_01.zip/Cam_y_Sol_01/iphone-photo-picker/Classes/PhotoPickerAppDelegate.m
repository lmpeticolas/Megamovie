//
//  PhotoPickerAppDelegate.m
//
/*
 
 Copyright (C) Adrian Buriks 2012
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 
 Copyright (C) Adrian Buriks 2012
 
 */

#import "PhotoPickerAppDelegate.h"

#import "PhotoPickerViewController.h"


@interface PhotoPickerAppDelegate ()
    - (void)checkIfJustInstalled;
    - (void)setupForUrl:(NSURL *)url;
@end


@implementation PhotoPickerAppDelegate

@synthesize defaultImageSource;
@synthesize justInstalled;
@synthesize launchedAsUrlHandler;
@synthesize postContext;   // Likely Post, camera, library
@synthesize viewController;
@synthesize window;


- (void) applicationDidBecomeActive:(UIApplication *) application
{
    
    // NOTE...
    // The application could be interrupted from any window.
    // Thus, we need to return to the window from which we left the application
    // unless we left from cancel button on the main screen.
    
    
    //[window addSubview:viewController.view];
    //[window makeKeyAndVisible];
    // Dispatch notification to controllers
    [[NSNotificationCenter defaultCenter] postNotificationName: @"didBecomeActive" 
                                                        object: nil 
                                                      userInfo: nil];
    
    
    //[self showPhotoSourceMenuOrPhotoSourceDirectly];
    
    
}

- (BOOL)application:(UIApplication *)application
        didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    

// Normally will start here.
// But this is only the first time.
    
    
    // If the dictionary is non-empty-> Application launched to handle a URL (i.e. launched from browser, for example).
    self.launchedAsUrlHandler = !!launchOptions; // Convert to a boolean

    self.defaultImageSource = -1;
    self.postContext = @""; // Empty string when application is launched.

    // Handle a URL based launch (This configures it using library, sending, or camera)
    // Might even be way this works from the first page with buttons.
    if (launchOptions) {
        NSURL *url = [launchOptions valueForKey:@"UIApplicationLaunchOptionsURLKey"];  // This is the url used to open this app
        [self setupForUrl:url];
    }

    [self checkIfJustInstalled];

    [window addSubview:viewController.view];
    [window makeKeyAndVisible];


    return YES;
}


- (void)dealloc {
    self.postContext = nil;    // Nil when freeing
    self.viewController = nil;
    self.window = nil;

    [super dealloc];
}


#pragma mark Private

// Configure the application to match user defaults.
- (void)checkIfJustInstalled {
    self.justInstalled = NO;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    id testForInstallKey = [defaults valueForKey:@"installed"];
    if (!testForInstallKey) {
        self.justInstalled = YES;
        [defaults setBool:YES forKey:@"installed"];
    }
}


// It appears that when the app is launched form an URL (Or perhaps from buttons)
// it can go straight to the camera or library. In these situations
// It needs to choose the right image source.
- (void)setupForUrl:(NSURL *)url {
    
    // Input is a NSURL we call "url"
    NSString *query = [url query];
    
    // If the query contains some data
    if ([query length]) {
        
        // Split the query into pairs separated by spaces
        NSArray *queryParts = [query componentsSeparatedByString:@"&"];
        
        // Parse each variable, value pair
        for (NSString *queryPart in queryParts) {

            // Split based upon the '='
            NSArray *kvp = [queryPart componentsSeparatedByString:@"="];
            // Set the key and value
            NSString *key = [kvp objectAtIndex:0];
            NSString *value = [kvp objectAtIndex:1];

            // Key named "context" -> Post
            if ([key isEqualToString:@"context"]) {     // We must send data to the destination
                
                // This tells to where we will post data.
                self.postContext = value;
            } 
            else if ([key isEqualToString:@"source"])   // We must get a picture from a source 
            
            {

                // The only source we will support is the photo library.
                self.defaultImageSource = UIImagePickerControllerSourceTypePhotoLibrary;

#if 0
                
                // camera -> Choose the camera as the source
                if ([value isEqualToString:@"camera"]) {
                    self.defaultImageSource = UIImagePickerControllerSourceTypeCamera;
                    
                // library -> Choose library as the source.    
                } else if ([value isEqualToString:@"library"]) {
                    self.defaultImageSource = UIImagePickerControllerSourceTypePhotoLibrary;
                }
#endif
            }
        }
    }
}


@end
