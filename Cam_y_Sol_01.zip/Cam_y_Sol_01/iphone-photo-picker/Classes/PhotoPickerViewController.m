//
//  PhotoPickerViewController.m
//
/*
 
 Copyright (C) Adrian Buriks 2012
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 
 Copyright (C) Adrian Buriks 2012
 
 */

#import "PhotoPickerViewController.h"

#import "NSData+PhotoPicker.h"
#import "PhotoPickerAppDelegate.h"
#import "UIImage+PhotoPicker.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <dispatch/dispatch.h>


static int kPhotoPickerViewControllerSourceIndexCamera = 0;
static int kPhotoPickerViewControllerSourceIndexPhotoLibrary = 1;
static int kPhotoPickerViewControllerMainMenu = 2;


@interface PhotoPickerViewController ()
    @property (nonatomic, retain) NSURLConnection *connection;
    @property (nonatomic, retain) NSData *imageData;
    @property (nonatomic, retain) NSHTTPURLResponse *response;
    @property (nonatomic, retain) NSMutableData *responseData;
    - (void)cancelApp;
    - (void)pickPhoto:(UIImagePickerControllerSourceType)sourceType;
    - (void)showPhotoSourceMenu;
    - (void)showPhotoSourceMenuOrPhotoSourceDirectly;
    - (void)uploadImage;
@end


@implementation PhotoPickerViewController


@synthesize connection;
@synthesize imageData;
@synthesize response;
@synthesize responseData;


#pragma mark UIActionSheetDelegate Methods


- (void)actionSheet:(UIActionSheet *)anActionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    [anActionSheet dismissWithClickedButtonIndex:buttonIndex animated:NO];

    if (buttonIndex == [anActionSheet cancelButtonIndex]) {
        // Where would we go?
        buttonIndex = kPhotoPickerViewControllerMainMenu;
        [self cancelApp];
    } 
#if 0
    if (buttonIndex == kPhotoPickerViewControllerSourceIndexCamera) {
        [self onCameraClicked];
    }  
 
 else
#endif     
    else if (buttonIndex == kPhotoPickerViewControllerSourceIndexPhotoLibrary) {
        // Where would we go?
        buttonIndex = kPhotoPickerViewControllerMainMenu;
        [self onPhotoLibraryClicked];
    } else 
        // Main menu
    {
        [self showPhotoSourceMenu];
    }
 
}


- (void)actionSheetCancel:(UIActionSheet *)actionSheet {
    // Do nothing.  Overriding default of simulating clicking cancel, when user hits home button.
}


#pragma mark UIImagePickerControllerDelegate Methods


- (void)imagePickerController:(UIImagePickerController *)picker
        didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    // Do nothing if buffer is not empty.
    if (nil != raw_JPEG_data)
        return;
        
    // Begin by showing a low res version of the image that should linger until we're done
    // This should be removed when we have either sent the image or given up.
    UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
    image = [image correctOrientation:image];
    self.imageData = UIImageJPEGRepresentation(image, 0.85f);
    uploadOverlayImage.image = image;
    uploadProgressMessage.text = @"uploading";
    uploadProgress.progress = 0.0f;
    uploadPhotoOverlay.frame = CGRectMake(0, 20, 320, 460);
    [[UIApplication sharedApplication].keyWindow addSubview:uploadPhotoOverlay];
    
    [picker.view removeFromSuperview];
    [picker release];
    
    ////////////////////////////////////////////////////////////
    ALAssetsLibrary *assetLibrary=[[ALAssetsLibrary alloc] init];

    [assetLibrary
     
       // asset URL = identifier for selected asset (likely a picture?)
       assetForURL:[info valueForKey:UIImagePickerControllerReferenceURL] 
    
       // The user will be asked inside this block what they want to do, etc.
       // Thus, whatever we want to do should be handled inside this block.
     
       // In this case, that will be functionality similar to "uploadImage" function.
       resultBlock:^(ALAsset *asset) 
         {
             // The respresentation of the ALAsset
             ALAssetRepresentation *rep = [asset defaultRepresentation];
             
             // Here we "malloc" the data
             // So, somewhere it must be freed later
             // However...we want that only upon completion or failure of send.
             // In that way, no reason to copy it from asset library again.
             
             Byte *buffer = (Byte*)malloc(rep.size);  //AAB - Does this get freed by dataWithBytesNoCopy?
             
             
             // Ask representation (rep) to fill buffer with raw data (It is assumed this was saved as JPEG)
             NSUInteger buffered = [rep getBytes:buffer fromOffset:0.0 length:rep.size error:nil];
             
             // The photo data to be sent in bytes.
             // By setting freeWhenDone = YES, raw_JPEG_data owns the bytes, and will free it when done.
             // However, we don't want them freed until the buffer has been sent or failed to send.
             // So, we say "retain"
             raw_JPEG_data = [[NSData dataWithBytesNoCopy:buffer length:buffered freeWhenDone:YES] retain];
             

             
             // UploadImage needs the picker to clear the screen.
             // Now that we have the nice buffer hanging of the main object, we can simply launch upload data on the main queue.
             
             // This is likely causing trouble with the NSURLConnection run loop settings.
             
             dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                 

                     [self uploadImage]; // Call the upload image function on the main queue.


             });
        
             // This should be done here, as we're no longer using the picker.       

             
         } 
         
         // AAB: Unable to get the asset for some reason
         // This likely needs to do something more than this (which is nothing)
         failureBlock:^(NSError *err) {
                     NSLog(@"Error: %@",[err localizedDescription]);
         }
     ];
    
    /////////////////////////////////////////////////////////////
    
    // Remnant [self uploadImage];


}


- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {

    [picker.view removeFromSuperview];
    [picker release];
    [self showPhotoSourceMenuOrPhotoSourceDirectly];
    
#if 0   
    // Cancel should do nothing more than pop up the browser.
    // Hitting the home button closes the app.
    BOOL shouldCancelApp = !cameraAvailable;
    #ifndef SHOW_SOURCE_MENU_IF_DEFAULT_SOURCE_CANCELLED
        PhotoPickerAppDelegate *appDelegate =
            (PhotoPickerAppDelegate *) [UIApplication sharedApplication].delegate;

        shouldCancelApp = shouldCancelApp || appDelegate.defaultImageSource >= 0;
    #endif

    if (shouldCancelApp) {
        [self cancelApp];
    } else {
        [picker.view removeFromSuperview];
        [picker release];

        [self showPhotoSourceMenuOrPhotoSourceDirectly];
    }
#endif
    
}


#pragma mark UIViewController Methods


- (void)viewDidLoad {
    
    #ifdef FORCE_ENABLE_CAMERA
        cameraAvailable = YES;
        fakeCameraAvailable = ![UIImagePickerController
            isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera];
    #else
    cameraAvailable = false;
    
//            [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera];
    #endif
    takePhotoButton.enabled = cameraAvailable;
    raw_JPEG_data = nil;
    
    // Seems to fix it just once.
//    [self showPhotoSourceMenuOrPhotoSourceDirectly];
    
    
    [[NSNotificationCenter defaultCenter] addObserver: self 
                                             selector: @selector(showPhotoSourceMenuOrPhotoSourceDirectly) 
                                                 name: @"didBecomeActive" 
                                               object: nil];
    
}


- (void)viewDidAppear:(BOOL)animated {

    [self showPhotoSourceMenuOrPhotoSourceDirectly];
    
#ifdef SHOW_SOURCE_MENU_IF_DEFAULT_SOURCE_CANCELLED
        PhotoPickerAppDelegate *appDelegate =
            (PhotoPickerAppDelegate *) [UIApplication sharedApplication].delegate;

        // Clearing the default image source in case the user goes back to the menu.
        appDelegate.defaultImageSource = -1;
#endif

}


#pragma mark URL Connection Event Handlers


// Final event, memory is cleaned up at the end of this.
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    self.connection = nil;
    self.response = nil;

    uploadProgress.progress = 0.0f;
    uploadProgressMessage.text = @"An error occurred, retrying in 10 seconds...";

    retryCounter = 10;
    [self performSelector:@selector(retry) withObject:nil afterDelay:1.0f];
}


// Final event, memory is cleaned up at the end of this.
- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    self.connection = nil;

    if ([self.response statusCode] == 200) {
        uploadProgress.progress = 1.0f;
        
        // This is the response from the server
        
        // For our current system, this is the web page sent back from the server (explaining contest issue)
        // In the past, this would be displayed in the browser.
        //
        // However, that's not what it should be for this application.
        // This application expects it to be something to be set in a variable called "response"
        NSString *responseString = [[[NSString alloc] initWithBytes:[self.responseData bytes]
                                                      length:[self.responseData length]
                                                      encoding:NSUTF8StringEncoding] autorelease];
        
        // The response from the CGI should be a list of variables that will be appended to the query information
        // This can then be used when we are sent back to the website after transmitting the photo.
        responseString =
            [responseString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        
        // What do we do with the response string?
            
        
        // This is where we go after we've sent our picture.
        // In the HTML 5 centric view of the world, this is the website. In fact,
        // we've snapped a single picture, and uploaded it.
        
        NSString *successContinueUrl = CONTINUE_URL;

        successContinueUrl =
            [successContinueUrl stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

        // Is there a quesiton mark in the returned data?
        BOOL hasQuestionMark = [successContinueUrl rangeOfString:@"?"].location != NSNotFound;

        // If the success control URL ends contains a ?, it's q query, so we need to add variables using &
        // If there are none, this will be the first variable (which is not preceded by &, but need to add the ?
        
        successContinueUrl =
            [successContinueUrl stringByAppendingString:hasQuestionMark ? @"&" : @"?"];
        
        
        // Observe the strange thing happening (OUR CGI does not do what this is expecting).
        // The CGI returns HTML for a web page...but this APP is expecting a response that can be appended to the URL
        // as a variable to be parsed by the website.
        
        successContinueUrl = [successContinueUrl stringByAppendingFormat:@"success=1&response=%@",responseString];
        
        
        // Free up this retained data, because image was sent correctly.
        if (nil != raw_JPEG_data){
            [raw_JPEG_data release];
            raw_JPEG_data = nil;
        };

        
        // Change this to return to the main screen!
        
        // Go back to the browser. This should be another CGI that will parse the "success" and response.
        // That query would handle a standard url-encoded form.

        // NOTE: Although this opens the browser, it does not kill this application. The application is simply minimized
        //       because the browser covers it.
        //
        // This was ok for ios 3.2, but is not acceptable for ios 4
        
        // This app should first go back to the main menu, then jump into the brower.

        // NOTE: Something similar to this window needs to be put
        //       on button that now says "Camera"
//        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:successContinueUrl]];
        
//////////////////// DIRECT COPY FROM THE CANCEL OPERATION ////////////////////////
//      We know that when we hit cancel, we go back to the main screen and
//      things work. So, simply copy and paste the same code here
//      and hope for the best.
        
        [self.connection cancel];
        self.connection = nil;
        
        [NSObject cancelPreviousPerformRequestsWithTarget:self
                                                 selector:@selector(retry)
                                                   object:nil];
        [NSObject cancelPreviousPerformRequestsWithTarget:self
                                                 selector:@selector(uploadImage)
                                                   object:nil];
        
        [uploadPhotoOverlay removeFromSuperview];
        
        // No longer planning to upload this image
#if 0
        // DUPLICATES EARLIER CODE
        if (nil != raw_JPEG_data)
        {
            [raw_JPEG_data release];
            raw_JPEG_data = nil;
        };
#endif
        [self showPhotoSourceMenuOrPhotoSourceDirectly];
        
        
    } else {
        uploadProgress.progress = 0.0f;
        uploadProgressMessage.text = @"An error occurred, retrying in 10 seconds...";

        retryCounter = 10;
        [self performSelector:@selector(retry) withObject:nil afterDelay:1.0f];
    }
    
    self.response = nil;
}


- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)newData {
  [responseData appendData:newData];
}


- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)newResponse {
  self.response = (NSHTTPURLResponse *) newResponse;
}


- (void)connection:(NSURLConnection *)connection
        didSendBodyData:(NSInteger)bytesWritten
        totalBytesWritten:(NSInteger)totalBytesWritten
        totalBytesExpectedToWrite:(NSInteger)totalBytesExpectedToWrite {
    
    uploadProgress.progress = (float) totalBytesWritten / totalBytesExpectedToWrite;
}


#pragma mark Public


- (IBAction)onCameraClicked {
    [self pickPhoto:UIImagePickerControllerSourceTypeCamera];
}


- (IBAction)onCancelUploadClicked {
    [self.connection cancel];
    self.connection = nil;

    [NSObject cancelPreviousPerformRequestsWithTarget:self
              selector:@selector(retry)
              object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self
              selector:@selector(uploadImage)
              object:nil];

    [uploadPhotoOverlay removeFromSuperview];
    
    // No longer planning to upload this image
    if (nil != raw_JPEG_data)
    {
        [raw_JPEG_data release];
        raw_JPEG_data = nil;
    };

    [self showPhotoSourceMenuOrPhotoSourceDirectly];
}


- (IBAction)onContinueRecommendationClicked {
    [self showPhotoSourceMenu];
}


- (IBAction)onPhotoLibraryClicked {
    [self pickPhoto:UIImagePickerControllerSourceTypePhotoLibrary];
}


#pragma mark Private


- (void)cancelApp {
    
    // This may open the web site...
    // But, when waking up from sleep must show screen again.
    
    NSString *cancelContinueUrl = CONTINUE_URL;

    cancelContinueUrl =
        [cancelContinueUrl stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

    BOOL hasQuestionMark = [cancelContinueUrl rangeOfString:@"?"].location != NSNotFound;

    cancelContinueUrl =
        [cancelContinueUrl stringByAppendingString:hasQuestionMark ? @"&" : @"?"];
    cancelContinueUrl = [cancelContinueUrl stringByAppendingString:@"success=0"];
    
    if (nil != raw_JPEG_data)
    { [raw_JPEG_data release];
        raw_JPEG_data = nil;
    }

    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:cancelContinueUrl]];
}


- (void)pickPhoto:(UIImagePickerControllerSourceType)sourceType {
    PhotoPickerAppDelegate *appDelegate =
        (PhotoPickerAppDelegate *) [UIApplication sharedApplication].delegate;

    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.delegate = self;

    // If the camera is force enabled, show the library instead.
#ifdef FORCE_ENABLE_CAMERA
        if (fakeCameraAvailable && sourceType == UIImagePickerControllerSourceTypeCamera) {
            sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        }
#endif

    imagePickerController.sourceType = sourceType;

    [appDelegate.window addSubview:imagePickerController.view];
}


- (void)retry {
    retryCounter--;

    if (retryCounter <= 0) {
        [self uploadImage];
    } else {
        uploadProgressMessage.text =
            [NSString stringWithFormat:@"An error occurred, retrying in %d second%@...",
                                       retryCounter,
                                       retryCounter != 1 ? @"s" : @""];

        [self performSelector:@selector(retry) withObject:nil afterDelay:1.0f];
    }
}


- (void)showPhotoSourceMenu {
    
// We don't want the user to be able to pick the camera
// no matter what.
    
    if (/*cameraAvailable*/ false) {
        photoSourceActionSheet = [[UIActionSheet alloc]
            initWithTitle:nil
            delegate:self
            cancelButtonTitle:nil //@"Cancel"
            destructiveButtonTitle:nil
            otherButtonTitles:@"Camera", @"Photo Library", nil];
        kPhotoPickerViewControllerSourceIndexCamera = 0;
        kPhotoPickerViewControllerSourceIndexPhotoLibrary = 1;
    } else {
        photoSourceActionSheet = [[UIActionSheet alloc]
            initWithTitle:nil
            delegate:self
            cancelButtonTitle:nil //@"Cancel"
            destructiveButtonTitle:nil
            otherButtonTitles:@"Choose Photo", nil];
        kPhotoPickerViewControllerSourceIndexCamera = -99;
        kPhotoPickerViewControllerSourceIndexPhotoLibrary = 0;
    }
    photoSourceActionSheet.actionSheetStyle = UIBarStyleDefault;

    UIImage *backgroundImage = [UIImage imageNamed:@"home-background.png"];
    UIView *background = [[UIImageView alloc] initWithImage:backgroundImage];
    background.frame = CGRectMake(0, -393 /*cameraAvailable ? -253 : -320*/, 320, 480);
    [photoSourceActionSheet insertSubview:background atIndex:0];

    [photoSourceActionSheet showInView:self.view];
}


- (void)showPhotoSourceMenuOrPhotoSourceDirectly {
    

    PhotoPickerAppDelegate *appDelegate =
        (PhotoPickerAppDelegate *) [UIApplication sharedApplication].delegate;

    if (!cameraAvailable ||
            appDelegate.defaultImageSource == UIImagePickerControllerSourceTypePhotoLibrary) 
    {
        [self onPhotoLibraryClicked];
        
    }
#if 0
    else if (appDelegate.defaultImageSource == UIImagePickerControllerSourceTypeCamera &&
                   cameraAvailable) {
        [self onCameraClicked];
    }
#endif
    
    else 

{
        [self showPhotoSourceMenu];
    }

}

- (void)uploadImage {
    
    ////////////////////////////////////////
    // When this is called, there should be data in "raw_JPEG_data" pointer.
    //
    // This will need to be freed when either the data is sent,
    // or we give up.
    //
    // We need to unload the image view when done too
    
    if (nil == raw_JPEG_data)
        return;
    
 
    
    CFUUIDRef tmpUUID = CFUUIDCreate(NULL);
    CFStringRef tmpfilename = CFUUIDCreateString(NULL, tmpUUID);
    CFRelease(tmpUUID);
    NSString * unique_filename = [(NSString *) tmpfilename autorelease];

    uploadProgress.progress = 0.0f;
    uploadProgressMessage.text = @"uploading";
    
    PhotoPickerAppDelegate *appDelegate =
    (PhotoPickerAppDelegate *) [UIApplication sharedApplication].delegate;

    
    // NOTE: We now create the request that would normally be output by
    //       a browser processing a file upload.
    NSMutableURLRequest *request =
    [NSMutableURLRequest requestWithURL:[NSURL URLWithString:UPLOAD_URL]];

    
    [request setHTTPMethod:@"POST"];
    
    NSString *boundary = @"---------------------------PicUpUcAR12-MuLTIPaRtFoRm";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    
    [request addValue:contentType forHTTPHeaderField:@"Content-Type"];
    
    // body is the bytes that will fill the body
    NSMutableData *body = [NSMutableData data];
    
    // This will be a "POST" message (postContext)
    [body appendData:[NSData utf8DataWithFormat:
                      @"--%@\r\nContent-Disposition: form-data; name=\"%@\"\r\n\r\n%@\r\n",
                      boundary,
                      @"context",
                      appDelegate.postContext]];
    
    [body appendData:[NSData utf8DataWithFormat:@"--%@\r\n", boundary]];
    [body appendData:[NSData utf8DataWithFormat:
                      @"Content-Disposition: form-data; name=\"%@\"; filename=\"%@.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n",
                      @"userfile",
                      unique_filename]];
    
    
    // NOTE: This has not yet been encoded with UTF8
    // Presumably, this gets handled automatically via the API
    [body appendData:raw_JPEG_data];
    
    [body appendData:[NSData utf8DataWithFormat:@"\r\n"]];
    
    [body appendData:[NSData utf8DataWithFormat:@"--%@--\r\n", boundary]];
    
    [request setHTTPBody:body];
    
    
    // We have packaged up the data to be sent now.
    
    // Create a buffer to hold the response from the server.
    self.responseData = [NSMutableData data];
#if 0 
    // An alternative to using a runloop.
    dispatch_async(dispatch_get_main_queue(), ^{
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES];
        [conn start];
    });
#endif
    
    // Set a class pointer "connection" to object handling sending, and place our own object as delegate.
    self.connection = [NSURLConnection connectionWithRequest:request delegate:self];
 //   [connection start];
    // What is a runloop? Just a separate thread sending messages?
    [[NSRunLoop currentRunLoop] runUntilDate:[NSDate distantFuture]];

    
}


@end
