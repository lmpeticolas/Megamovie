/*
     File: AVCamViewController.h
 Abstract: A view controller that coordinates the transfer of information between the user interface and the capture manager.
  Version: 1.2
*/

/*
 
 Copyright (C) Adrian Buriks 2012
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 
 Copyright (C) Adrian Buriks 2012
 
 */
#import <AudioToolbox/AudioToolbox.h>
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

#define NUM_PHOTOS_PER_CLICK 3

// Number of seconds before and after center of eclipse
// This is where we place the center of each photo.
#define TIME_WINDOW_ECLIPSE (5 * 60)

#define NUM_PICS 11
#if (( (!(NUM_PICS / 2 * 2)) == NUM_PICS) || (NUM_PICS == 0) || (NUM_PICS < 0))
#error "Error: NUM_PICS must be odd number greater than zero."
#endif


// NOTE: This is global (a bit ugly)


@class AVCamCaptureManager, AVCamPreviewView, AVCaptureVideoPreviewLayer;

//AAB: I see no need for image picker at present.
@interface AVCamViewController : UIViewController </*UIImagePickerControllerDelegate,*/UINavigationControllerDelegate> {
    
    
    
    // Non-Pointers
    bool exists;
    bool countdown_started;
    unsigned char camera_state;
    
    bool is_countdown_enabled;
    
    bool is_camera_present;  // true if the device has a camera
    bool is_inside_interval; // true when inside a time interval allowing pictures to be taken.
    bool is_processing_picture; // true after button is pressed, but before picture taken.
    
// AAB: Not needed (use UI control to figure this out)    bool photo_button_is_enabled;
    
    NSInteger current_year_diff_displayed;
    NSInteger current_month_diff_displayed;
    NSInteger current_day_diff_displayed;
    NSInteger current_hour_diff_displayed;
    NSInteger current_minute_diff_displayed;
    NSInteger current_second_diff_displayed;

    
// Pointers    
    
    // These are pointing to something elsewhere
    // They are set up so that they won't be used after they're released
    CALayer *savedViewLayer;
    UIView *savedView;

    // This is only allocated in one place (at start) and then deallocated at the end.
    CLLocationManager *locationManager;

    // These are variables that may change each time we start the app
    // For the first version, they will always have a date or string attached.
    NSDate * eclipse_start_date_time;
    NSDate * eclipse_end_date_time;

    NSString * lat_degrees_info_str;// = @"";
    NSString * lon_degrees_info_str;// = @"";
#if 0   
    NSString * eclipse_start_date_info_str;// = @"";
#endif
    NSString * eclipse_start_time_info_str; // = @"Current year is outside the range 2012-2035.";
    NSString * eclipse_end_time_info_str;// = @"No eclipse calculated.";
    NSString * eclipse_countdown_info_str;
    
    
    // Plain old C arrays of pointers to dates
    NSDate * eclipse_interval_start_date_time[NUM_PICS];
    NSDate * eclipse_interval_end_date_time[NUM_PICS];
    
    CFURLRef soundFileURLRef;
    SystemSoundID soundFileObject;
    
    int photoCount;

}


// All these should retain what they're pointing to.

@property (nonatomic,retain) AVCamCaptureManager *captureManager;
@property (nonatomic,retain) IBOutlet UIView *videoPreviewView;
@property (nonatomic,retain) AVCaptureVideoPreviewLayer *captureVideoPreviewLayer;
@property (nonatomic,retain) IBOutlet UIBarButtonItem *stillButton;

// Original label from demo app
@property (nonatomic,retain) IBOutlet UILabel *focusModeLabel;

// New labels for Eclipse app
// Location related
@property (nonatomic,retain) IBOutlet UILabel *locTitleLabel;

@property (nonatomic,retain) IBOutlet UILabel *locLatLabel;
@property (nonatomic,retain) IBOutlet UILabel *locLatInfoLabel;

@property (nonatomic,retain) IBOutlet UILabel *locLongLabel;
@property (nonatomic,retain) IBOutlet UILabel *locLongInfoLabel;


@property (nonatomic,retain) IBOutlet UILabel *locAltLabel;

// Eclipse related
@property (nonatomic,retain) IBOutlet UILabel *ecDateTimeTitleLabel;

//Start time
@property (nonatomic,retain) IBOutlet UILabel *ecDateTimeStartLabel;
@property (nonatomic,retain) IBOutlet UILabel *ecDateTimeStartInfoLabel;

//End time
@property (nonatomic,retain) IBOutlet UILabel *ecDateTimeEndLabel;
@property (nonatomic,retain) IBOutlet UILabel *ecDateTimeEndInfoLabel;


// Countdown
@property (nonatomic,retain) IBOutlet UILabel *ecCountdownTitleLabel;
//@property (nonatomic,retain) IBOutlet UILabel *ecDaysLeftLabel;
@property (nonatomic,retain) IBOutlet UILabel *ecTimeLeftLabel;


-(void) Countdown;
-(bool) adjust_exposure:(double) exposure_seconds; // I long the exposure should be in seconds.
- (void) updateLocation;
#if 0
// For testing only when no location services available
-(void) stubLocationManager;
#endif

- (NSString *) uniqueAppID;

#pragma mark Toolbar Actions

- (IBAction)captureStillImage:(id)sender;


@end

