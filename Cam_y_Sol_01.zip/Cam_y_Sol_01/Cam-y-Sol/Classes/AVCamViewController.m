/*
     File: AVCamViewController.m
 Abstract: A view controller that coordinates the transfer of information between the user interface and the capture manager.
  Version: 1.2
*/

/*
 
 Copyright (C) Adrian Buriks 2012
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 
 Copyright (C) Adrian Buriks 2012
 
 */

#import "AVCamViewController.h"
#import "AVCamCaptureManager.h"
#import <AVFoundation/AVFoundation.h>
#import <dispatch/dispatch.h>
#include "ecalc_extern.h"
#include <time.h>
#include <stdio.h>


static void *AVCamFocusModeObserverContext = &AVCamFocusModeObserverContext;

// NOTE: This is global, which is a bit ugly...but...


@interface AVCamViewController () <UIGestureRecognizerDelegate, CLLocationManagerDelegate> {
    
}
@end

@interface AVCamViewController (InternalMethods)
- (CGPoint)convertToPointOfInterestFromViewCoordinates:(CGPoint)viewCoordinates;
- (void)tapToAutoFocus:(UIGestureRecognizer *)gestureRecognizer;
- (void)tapToContinouslyAutoFocus:(UIGestureRecognizer *)gestureRecognizer;
- (void)updateButtonStates;
//- (void)applicationDidBecomeActive; - Not sure, but this doesn't seem to be needed.
@end

@interface AVCamViewController (AVCamCaptureManagerDelegate) <AVCamCaptureManagerDelegate>
@end

@implementation AVCamViewController

@synthesize captureManager;
@synthesize stillButton;

@synthesize focusModeLabel;

@synthesize locTitleLabel;
@synthesize locLatLabel;
@synthesize locLatInfoLabel;
@synthesize locLongLabel;
@synthesize locLongInfoLabel;
@synthesize locAltLabel;

@synthesize ecDateTimeTitleLabel;
@synthesize ecDateTimeStartLabel;
@synthesize ecDateTimeStartInfoLabel;
@synthesize ecDateTimeEndLabel;
@synthesize ecDateTimeEndInfoLabel;

@synthesize ecCountdownTitleLabel;
@synthesize ecTimeLeftLabel;



@synthesize videoPreviewView;
@synthesize captureVideoPreviewLayer;

- (NSString *) uniqueAppID{
    
    FILE *fp_read;
    FILE *fp_write;
    int i;
    int c;
    int id_error;
    unsigned char id_byte_array[16]; // Bytes of the string
    unsigned char id_byte_array_final[16];
    id_error = 0;
    //NSString* basePath = [[NSString alloc] initWithUTF8String:name.c_str()];
    
    NSBundle* mainBundle = [NSBundle mainBundle];
    NSString* path = [mainBundle pathForResource:@"app_id" ofType:@"txt"];
    
    fp_read  = NULL;
    fp_write = NULL;
    
    id_error = 0;
    // Initial file is empty.
    // However we should be able to open it.
    
    // Always create an ID
    CFUUIDRef    tmpUUID     = CFUUIDCreate(nil);
    CFUUIDBytes  ID_bytes    = CFUUIDGetUUIDBytes(tmpUUID);
    
    // To avoid any packing issues due to compiler settings.
    id_byte_array[0]     = ID_bytes.byte0;
    id_byte_array[1]     = ID_bytes.byte1;
    id_byte_array[2]     = ID_bytes.byte2;
    id_byte_array[3]     = ID_bytes.byte3;
    id_byte_array[4]     = ID_bytes.byte4;
    id_byte_array[5]     = ID_bytes.byte5;
    id_byte_array[6]     = ID_bytes.byte6;
    id_byte_array[7]     = ID_bytes.byte7;
    id_byte_array[8]     = ID_bytes.byte8;
    id_byte_array[9]     = ID_bytes.byte9;
    id_byte_array[10]    = ID_bytes.byte10;
    id_byte_array[11]    = ID_bytes.byte11;
    id_byte_array[12]    = ID_bytes.byte12;
    id_byte_array[13]    = ID_bytes.byte13;
    id_byte_array[14]    = ID_bytes.byte14;
    id_byte_array[15]    = ID_bytes.byte15;
    
    CFRelease(tmpUUID);

    
    if (NULL != (fp_read = fopen(path.UTF8String,"r+")))
    {
        // If the file doesn't have at least 32 characters, this
        // is the first time we call the function.
        fseek(fp_read, 0, SEEK_END);
        
        long file_pos = ftell(fp_read);
        
        rewind(fp_read);
        
        if (file_pos < 10){
        
        
           // Write the unique ID to a binary file.
           for (i = 0; i < 16; ++i){
               if (EOF == fputc((int) id_byte_array[i], fp_read))
               {
                   id_error = 2;
                   break;
               }
           }

            fflush(fp_read);
            rewind(fp_read);
            
        };   
           // Regardless of whether succeed of fail, close the file.
           
//           CFStringRef string = CFUUIDCreateString(nil, theUUID);
//           return [(NSString *)string autorelease];
//           fp_read = fopen(path.UTF8String,"rb"); 
       
        for (i = 0; i < 16 && (0 == id_error); ++i){
            if (EOF == (c = fgetc(fp_read))){
                id_error = 3;
                break;
            }
            else
                id_byte_array_final[i] = (unsigned char) c;
            
        };
        
        fclose(fp_read);
    };

    if (id_error != 0)
    {
        for (i = 0; i < 16; ++i)
            id_byte_array_final[i] = id_byte_array[i];
    }
    // We now have the ID in the array
    // This can now be converted to a string of hex characters.
    NSMutableString *str = [NSMutableString stringWithCapacity:64];

    for (i = 0; i < 16; i++)
    {
    	[str appendFormat:@"%02X", id_byte_array_final[i]];
    }
    
    return [NSString stringWithString:str];

}

- (NSString *)stringForFocusMode:(AVCaptureFocusMode)focusMode
{
	NSString *focusString = @"";
	
	switch (focusMode) {
		case AVCaptureFocusModeLocked:
			focusString = @"locked";
			break;
		case AVCaptureFocusModeAutoFocus:
			focusString = @"auto";
			break;
		case AVCaptureFocusModeContinuousAutoFocus:
			focusString = @"continuous";
			break;
	}
	
	return focusString;
}

- (void)dealloc
{
    int i;
    [self removeObserver:self forKeyPath:@"captureManager.videoInput.device.focusMode"];
    [[NSNotificationCenter defaultCenter] removeObserver:self];

    
// AAB: Now in another class.    [unique_id release];
	[captureManager release];
    [videoPreviewView release];
	[captureVideoPreviewLayer release];

    [stillButton release];	
	[focusModeLabel release];
    
    [locTitleLabel release];

    [locLatLabel release];
    [locLatInfoLabel release];
    
    [locLongLabel release];
    [locLongInfoLabel release];
    
#if 0
    // May be added in the future.
    [locAltLabel release];
#endif    
    [ecDateTimeTitleLabel release];
    
//  [EcDateTimeDateInfoLabel release];
    
    
    // NOTE: Start of Eclipse may be on different days!
    //       This could occur at northerly locations where it's always light at night.
    //       This should therefore be handled correctly with the date API from Apple.
    //       Not hackish solution.
    
    [ecDateTimeStartLabel release];
    [ecDateTimeStartInfoLabel release];
    
    // Get rid of the list of intervals (there shouldn't be too many)
    // NOTE: This should also be an odd number
    // So that equal numbers before and after and one at center.
    for (i = 0; i < NUM_PICS; ++i)
    {
        [eclipse_interval_start_date_time[i] release];
        [eclipse_interval_end_date_time[i] release];
    }
    
    [ecDateTimeEndLabel release];
    [ecDateTimeEndInfoLabel release];
    
    [ecCountdownTitleLabel release];
    [ecTimeLeftLabel release];
    
    // Also, must deallocate the dates and strings
    [eclipse_start_date_time release];
    [eclipse_end_date_time release];
    
    [lat_degrees_info_str release];
    [lon_degrees_info_str release];
    [eclipse_start_time_info_str release];
    [eclipse_end_time_info_str release];
    [eclipse_countdown_info_str release];
    
    
    [locationManager release];
    
 // Maybe this causes issues   
    CFRelease(soundFileURLRef);

    // This last
    [super dealloc];
}

- (void)viewDidLoad
{

// AAB: There seems to be a bug with this project causing this to be called twice.
//      This is present for even the demo app provided from Apple. To speed initialization
//      the following test has been added. At some point this should be debugged.
int i;
if (!exists){
    
    
    // Create the URL for the source audio file. The URLForResource:withExtension: method is
    //    new in iOS 4.0.
    //CFBundleRef mainBundle = CFBundleGetMainBundle ();
  
    NSURL *readySound   = [[NSBundle mainBundle] URLForResource: @"ReadyForPic"
                                                withExtension: @"wav"];
    
    // Store the URL as a CFURLRef instance
    // This likely needs to be released somewhere.
    
    soundFileURLRef = (CFURLRef) [readySound retain];
    
    // Create a system sound object representing the sound file.

                               
    AudioServicesCreateSystemSoundID (
                                      
                                      soundFileURLRef,
                                      &soundFileObject
                                      );
    
// AAB: Now in another class    unique_id = [[self uniqueAppID] retain];
    
    is_inside_interval = false;
    is_processing_picture = false;
    is_camera_present = false;
    //is_countdown_enabled = false;  Handled in other startup function.
    
    // is_camera_present set in updateButtonStates.

    [NSTimeZone systemTimeZone];
// AAB: Redundant: Use the UI control to    photo_button_is_enabled = false; // Initially, disabled.
    
// We give them all something to point to
    
    // Numerou/Users/A/Documents/Cam_y_Sol_01/Cam-y-Sol/Resources/MainWindow.xibs date objects
    // We do not want these initialized with anything close to the current date.
    
    eclipse_start_date_time = [[NSDate alloc] initWithTimeIntervalSince1970:0];
    eclipse_end_date_time = [[NSDate alloc] initWithTimeIntervalSince1970:0];

    for (i = 0; i < NUM_PICS; ++i)
    {
        eclipse_interval_start_date_time[i] = [[NSDate alloc] initWithTimeIntervalSince1970:0];
        eclipse_interval_end_date_time[i] = [[NSDate alloc] initWithTimeIntervalSince1970:0];
    }
    
    // Dynamic information fields.
    lat_degrees_info_str = [[NSString alloc] initWithString:@""];
    lon_degrees_info_str = [[NSString alloc] initWithString:@""];
    eclipse_start_time_info_str = [[NSString alloc] initWithString:@""];
    eclipse_end_time_info_str = [[NSString alloc] initWithString:@""];
    eclipse_countdown_info_str = [[NSString alloc] initWithString:@""];
    
    
    // Register to hear about when the application becomes active after sleeping.
    // We are not using appDelegate for this app, so it will be done this way.
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(applicationDidBecomeActive:)
                                                 name:UIApplicationDidBecomeActiveNotification object:nil];

    // Register to hear when appliction entered background
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(applicationDidEnterBackground:)
                                                 name:UIApplicationDidEnterBackgroundNotification object:nil];
    
    [[self stillButton] setTitle:NSLocalizedString(@"Photo", @"Take photos of Eclipse.")];
    // Initially this is off
    [[self stillButton] setEnabled:NO];
    
	if ([self captureManager] == nil) {
		AVCamCaptureManager *manager = [[AVCamCaptureManager alloc] init];
		[self setCaptureManager:manager];
		[manager release];
		
		[[self captureManager] setDelegate:self];
        
        // AAB: This is a bit ugly, but the unique value is needed in the class
        //      writing data. That is the captureManager class.
        
        [self captureManager]->unique_id = [[self uniqueAppID] retain];

		if ([[self captureManager] setupSession]) {
            
            // Create video preview layer and add it to the UI
			AVCaptureVideoPreviewLayer *newCaptureVideoPreviewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:[[self captureManager] session]];
			UIView *view = [self videoPreviewView];
            savedView = view;
            
            
			CALayer *viewLayer = [view layer];
            
            // Is this allowed?
            savedViewLayer = viewLayer;
			
            [viewLayer setMasksToBounds:YES];
			
			CGRect bounds = [view bounds];
			[newCaptureVideoPreviewLayer setFrame:bounds];
			
			if ([newCaptureVideoPreviewLayer isOrientationSupported]) {
				[newCaptureVideoPreviewLayer setOrientation:AVCaptureVideoOrientationPortrait];
			}
			
			[newCaptureVideoPreviewLayer setVideoGravity:AVLayerVideoGravityResizeAspectFill];
			
			[viewLayer insertSublayer:newCaptureVideoPreviewLayer below:[[viewLayer sublayers] objectAtIndex:0]];
			
			[self setCaptureVideoPreviewLayer:newCaptureVideoPreviewLayer];
            [newCaptureVideoPreviewLayer release];
			
            // Start the session. This is done asychronously since -startRunning doesn't return until the session is running.
			dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
				[[[self captureManager] session] startRunning];
			});
			
            // Sets state of is_camera_present
            [self updateButtonStates];
            
            
// Create user interface elements programmatically
            
            // Original focus text from demo.
			
            // Create the focus mode UI overlay
			UILabel *newFocusModeLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, viewLayer.bounds.size.width - 20, 20)];
			[newFocusModeLabel setBackgroundColor:[UIColor clearColor]];
			[newFocusModeLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
			AVCaptureFocusMode initialFocusMode = [[[captureManager videoInput] device] focusMode];
			[newFocusModeLabel setText:[NSString stringWithFormat:@"focus: %@", [self stringForFocusMode:initialFocusMode]]];
			[view addSubview:newFocusModeLabel];
			[self addObserver:self forKeyPath:@"captureManager.videoInput.device.focusMode" options:NSKeyValueObservingOptionNew context:AVCamFocusModeObserverContext];
			[self setFocusModeLabel:newFocusModeLabel];
            [newFocusModeLabel release];
            
            
            // Create UI Labels with data calculated at startup of application.
            
            // Create the Location label
			UILabel *newLocTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 50, viewLayer.bounds.size.width - 20, 20)];
			[newLocTitleLabel setBackgroundColor:[UIColor clearColor]];
			[newLocTitleLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
			[newLocTitleLabel setText:[NSString stringWithFormat:@"Location", nil]];
			[view addSubview:newLocTitleLabel];
			[self setLocTitleLabel:newLocTitleLabel];
            [newLocTitleLabel release];
            

            // Create the Latitude label
			UILabel *newLocLatLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 70, viewLayer.bounds.size.width - 20, 20)];
			[newLocLatLabel setBackgroundColor:[UIColor clearColor]];
			[newLocLatLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
			[newLocLatLabel setText:[NSString stringWithFormat:@"Latitude:", nil]];
			[view addSubview:newLocLatLabel];
			[self setLocLongLabel:newLocLatLabel];
            [newLocLatLabel release];

            // Now create the latitude information label
            UILabel *newLocLatInfoLabel = [[UILabel alloc] initWithFrame:CGRectMake(110, 70, savedViewLayer.bounds.size.width - 20, 20)];
            [newLocLatInfoLabel setBackgroundColor:[UIColor clearColor]];
            [newLocLatInfoLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
            [newLocLatInfoLabel setText:lat_degrees_info_str];
            [savedView addSubview:newLocLatInfoLabel];
            [self setLocLatInfoLabel:newLocLatInfoLabel];
            [newLocLatInfoLabel release];    

            
            // Create the Longitude label
			UILabel *newLocLongLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 90, viewLayer.bounds.size.width - 20, 20)];
			[newLocLongLabel setBackgroundColor:[UIColor clearColor]];
			[newLocLongLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
			[newLocLongLabel setText:[NSString stringWithFormat:@"Longitude:", nil]];
			[view addSubview:newLocLongLabel];
			[self setLocLongLabel:newLocLongLabel];
            [newLocLongLabel release];
            
            
            // Create the Longitude information label
            UILabel *newLocLongInfoLabel = [[UILabel alloc] initWithFrame:CGRectMake(110, 90, savedViewLayer.bounds.size.width - 20, 20)];
            [newLocLongInfoLabel setBackgroundColor:[UIColor clearColor]];
            [newLocLongInfoLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
            [newLocLongInfoLabel setText:lon_degrees_info_str];
            [savedView addSubview:newLocLongInfoLabel];
            [self setLocLongInfoLabel:newLocLongInfoLabel];
            [newLocLongInfoLabel release];

            
#if 0 
            //NOT USED AT PRESENT
            // Create an Altitude title.
			UILabel *newLocAltLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 90, viewLayer.bounds.size.width - 20, 20)];
			[newLocAltLabel setBackgroundColor:[UIColor clearColor]];
			[newLocAltLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
            //			AVCaptureFocusMode initialFocusMode = [[[captureManager videoInput] device] focusMode];
            // NOTE: We are using the format string to display the text...but it's easy.
			[newLocAltLabel setText:[NSString stringWithFormat:@"Altitude:", nil]];
			[view addSubview:newLocAltLabel];
            //			[self addObserver:self forKeyPath:@"captureManager.videoInput.device.focusMode" options:NSKeyValueObservingOptionNew context:AVCamFocusModeObserverContext];
			[self setLocLongLabel:newLocAltLabel];
            [newLocAltLabel release];
#endif           
            
            // Create the Eclipse: information labels
            
            // Create the Date Time Title label
			UILabel *newEcDateTimeTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 120, viewLayer.bounds.size.width - 20, 20)];
			[newEcDateTimeTitleLabel setBackgroundColor:[UIColor clearColor]];
			[newEcDateTimeTitleLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
			[newEcDateTimeTitleLabel setText:[NSString stringWithFormat:@"Eclipse:", nil]];
			[view addSubview:newEcDateTimeTitleLabel];
			[self setEcDateTimeTitleLabel:newEcDateTimeTitleLabel];
            [newEcDateTimeTitleLabel release];

            
            // Create the Date Time Start label
			UILabel *newEcDateTimeStartLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 140, viewLayer.bounds.size.width - 20, 20)];
			[newEcDateTimeStartLabel setBackgroundColor:[UIColor clearColor]];
			[newEcDateTimeStartLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
			[newEcDateTimeStartLabel setText:[NSString stringWithFormat:@"Start:", nil]];
			[view addSubview:newEcDateTimeStartLabel];
			[self setEcDateTimeStartLabel:newEcDateTimeStartLabel];
            [newEcDateTimeStartLabel release];
            
            
            // Create the Date Time Start information label
			UILabel *newEcDateTimeStartInfoLabel = [[UILabel alloc] initWithFrame:CGRectMake(110, 140, viewLayer.bounds.size.width - 20, 20)];
			[newEcDateTimeStartInfoLabel setBackgroundColor:[UIColor clearColor]];
			[newEcDateTimeStartInfoLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
			[newEcDateTimeStartInfoLabel setText:eclipse_start_time_info_str];
			[view addSubview:newEcDateTimeStartInfoLabel];
			[self setEcDateTimeStartInfoLabel:newEcDateTimeStartInfoLabel];
            [newEcDateTimeStartInfoLabel release];
            
            
            // Create the Date Time End label
			UILabel *newEcDateTimeEndLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 160, viewLayer.bounds.size.width - 20, 20)];
			[newEcDateTimeEndLabel setBackgroundColor:[UIColor clearColor]];
			[newEcDateTimeEndLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
			[newEcDateTimeEndLabel setText:[NSString stringWithFormat:@"End:", nil]];
			[view addSubview:newEcDateTimeEndLabel];
			[self setEcDateTimeEndLabel:newEcDateTimeEndLabel];
            [newEcDateTimeEndLabel release];
            
            // Create the Date Time End Information label
			UILabel *newEcDateTimeEndInfoLabel = [[UILabel alloc] initWithFrame:CGRectMake(110, 160, viewLayer.bounds.size.width - 20, 20)];
			[newEcDateTimeEndInfoLabel setBackgroundColor:[UIColor clearColor]];
			[newEcDateTimeEndInfoLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
			[newEcDateTimeEndInfoLabel setText:eclipse_end_time_info_str];
			[view addSubview:newEcDateTimeEndInfoLabel];
			[self setEcDateTimeEndInfoLabel:newEcDateTimeEndInfoLabel];
            [newEcDateTimeEndInfoLabel release];

//            ecCountdownTitleLabel
            // Create the DateTime information UI overlay
			UILabel *newEcCountDownLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 190, viewLayer.bounds.size.width - 20, 20)];
			[newEcCountDownLabel setBackgroundColor:[UIColor clearColor]];
			[newEcCountDownLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
			[newEcCountDownLabel setText:[NSString stringWithFormat:@"Countdown yr:mon:day hr:min:sec", nil]];
			[view addSubview:newEcCountDownLabel];

			[self setLocLongLabel:newEcCountDownLabel];
            [newEcCountDownLabel release];

//            ecTimeLeftLabel          
            UILabel *newEcTimeLeftLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 210, viewLayer.bounds.size.width - 20, 20)];
			[newEcTimeLeftLabel setBackgroundColor:[UIColor clearColor]];
			[newEcTimeLeftLabel setTextColor:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.50]];
            //			AVCaptureFocusMode initialFocusMode = [[[captureManager videoInput] device] focusMode];
            // NOTE: We are using the format string to display the text...but it's easy.
			[newEcTimeLeftLabel setText:eclipse_countdown_info_str];
			[view addSubview:newEcTimeLeftLabel];
            //			[self addObserver:self forKeyPath:@"captureManager.videoInput.device.focusMode" options:NSKeyValueObservingOptionNew context:AVCamFocusModeObserverContext];
			[self setEcTimeLeftLabel:newEcTimeLeftLabel];
            [newEcTimeLeftLabel release];
            
            // Add a single tap gesture to focus on the point tapped, then lock focus
			UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapToAutoFocus:)];
			[singleTap setDelegate:self];
			[singleTap setNumberOfTapsRequired:1];
			[view addGestureRecognizer:singleTap];
			
            // Add a double tap gesture to reset the focus mode to continuous auto focus
			UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapToContinouslyAutoFocus:)];
			[doubleTap setDelegate:self];
			[doubleTap setNumberOfTapsRequired:2];
			[singleTap requireGestureRecognizerToFail:doubleTap];
			[view addGestureRecognizer:doubleTap];
			
			[doubleTap release];
			[singleTap release];
            
            locationManager = [[CLLocationManager alloc] init];  
            
		}		
	}
		
    [super viewDidLoad];
    
    // Protect against multiple loads.
    exists = true;
        
    };
    

}
- (void) updateLocation{
    // We'll init it when the app opens, and kill it delete it upon getting the first message.
    // NOTE: This did not always seem to be called.
#if 0
    // For testing only when no location services available
    [self stubLocationManager];
    return;
#endif    
    if ([CLLocationManager locationServicesEnabled] == NO) {
        UIAlertView *servicesDisabledAlert = [[UIAlertView alloc] initWithTitle:@"Location Services Disabled" message:@"To obtain accurate eclipse times, location services should be enabled for this application using the Settings app." delegate:nil cancelButtonTitle:@"Cancel" otherButtonTitles:nil];
        [servicesDisabledAlert show];
        [servicesDisabledAlert release];
        
        // Does not work.
        // Interestingly, some other apps in demos worked.[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"prefs:root=General"]];
    }
    
    else
    {
        
        // Set the accuracy
        [locationManager setDesiredAccuracy:kCLLocationAccuracyKilometer];
        
        // Set this object to receive messages
        [locationManager setDelegate:self];
        
        // Start the service (NOTE: This also seems to get called the first time in the appDidBecomeActive method.
        // But, that's not an issue.
        [locationManager startUpdatingLocation];
        
    }        
    
}
// Name chosen to be the same as Apple's typical AppDelegate style method
- (void) applicationDidBecomeActive:(NSNotification *)notification{
    // Countdown is not enabled unless data structures populated at startup.
    [self updateLocation];

}

-(void) applicationDidEnterBackground:(NSNotification *)notification{
  
    is_countdown_enabled = false;
}
-(bool) adjust_exposure:(double) exposure_seconds{
    
    // Play a beeping noise on a separate thread.
    
    // Play a sound and Vibrate (if configured do do that by user)
     AudioServicesPlayAlertSound (soundFileObject);
    
    return true;
}

// This function is called approximately once each second to update counters, and handle logic of enabling/disabling the photo button.
// After completing it's task, it adds another request to update the times on the display.
// To make limit the number of times it might skip displaying a second, updates are scheduled a bit more frequently
// than once each second.

#define OUTSIDE_WINDOW_EXP_NOT_ADJUSTED_PIC_INCOMPLETE_BUTTON_DISABLED  0
// NOTE NEEDED: #define INSIDE_WINDOW_EXP_ADJUSTING_PIC_INCOMPLETE_BUTTON_DISABLED      1
#define INSIDE_WINDOW_EXP_ADJUSTED_PIC_INCOMPLETE_BUTTON_ENABLED        1
// NOT NEEDED: #define INSIDE_WINDOW_EXP_ADJUSTED_PIC_PROCESSING_BUTTON_DISABLED       3
#define INSIDE_WINDOW_EXP_ADJUSTED_PIC_COMPLETE_BUTTON_DISABLED         2

double exposure_times[] = { 
    .0166666667f,
    .0166666667f,      
    .0166666667f,
    .0166666667f,
    .0166666667f,
    .0166666667f,        
    .0166666667f,
    .0166666667f,
    .0166666667f,
    .0166666667f,
    .0166666667f
    
};

-(void) Countdown{

    // Countdown always takes place, but sometimes no action is taken.

    // When application goes to sleep and wakes up,
    // various structures are re-initialized (in particular intervals array)
    // These must not be accessed until populated again.
    // So, when shutting down, this is set to false.
    // Once arrays have been popluated, this is again set to true.
    if (true == is_countdown_enabled){
    int i;
    // This is the current date.
    NSDate * currentDate = [NSDate date];

    // Scan interval
    //bool is_inside_interval; Now global
    int pic_interval = -1;
    
    is_inside_interval = false;
    for (i = 0; i < NUM_PICS; ++i){
        
        if (([currentDate timeIntervalSinceDate:eclipse_interval_start_date_time[i]] >= 0) &&
            ([currentDate timeIntervalSinceDate:eclipse_interval_end_date_time[i]] <= 0)){
            pic_interval = i;         
            is_inside_interval = true;
            break;
        }
    }
    
    // NOTE: When we are in this state, we are not displaying the countdown anyway.
    switch(camera_state)
    {
        case OUTSIDE_WINDOW_EXP_NOT_ADJUSTED_PIC_INCOMPLETE_BUTTON_DISABLED:
            // Will keep trying if this fails.
            if ((true == is_camera_present) &&
                (true == is_inside_interval) &&
                (false == is_processing_picture)
            ){
                // adjust_exposure will handle the entire process.
                if ([self adjust_exposure:exposure_times[pic_interval]] == true)
                    [[self stillButton] setEnabled:YES];
                else
                    [[self stillButton] setEnabled:NO];
                
                camera_state = INSIDE_WINDOW_EXP_ADJUSTED_PIC_INCOMPLETE_BUTTON_ENABLED;
            };
                
            break;
        
        case INSIDE_WINDOW_EXP_ADJUSTED_PIC_INCOMPLETE_BUTTON_ENABLED:
            // NOTE: Change to the next state occurs only with a button press, when an image
            //       is processed and saved.
            if ((true == is_camera_present) &&
                (false == is_inside_interval)
               )
            {
                [[self stillButton] setEnabled:NO];
                is_processing_picture = false;
                camera_state = OUTSIDE_WINDOW_EXP_NOT_ADJUSTED_PIC_INCOMPLETE_BUTTON_DISABLED;
            }

            break;
            
        case INSIDE_WINDOW_EXP_ADJUSTED_PIC_COMPLETE_BUTTON_DISABLED:
            if ((true == is_camera_present) &&
                (false == is_inside_interval)
                ){
                is_processing_picture = false;
                [[self stillButton] setEnabled:NO];
                camera_state = OUTSIDE_WINDOW_EXP_NOT_ADJUSTED_PIC_INCOMPLETE_BUTTON_DISABLED;
            }
            break;
            
        default: // Do nothing
            break;
            
            
    }

    // NOTE: The following no longer handles button enable/disable
    //       However, it still handles proper display of dates.
    
    // Update this to countdown to next picture.
    
    // Time interval 15 minutes before or after eclipse
    if (([currentDate timeIntervalSinceDate:eclipse_start_date_time] >= (-15 * 60)) &&
        ([currentDate timeIntervalSinceDate:eclipse_end_date_time]) < (15 * 60))
    {
        // Within eclipse window (plus or minus 15 min)
        // Enable the photo button.
        // Clear the countown label, and enable the photo button
//        [[self stillButton] setEnabled:YES];
        
        [eclipse_countdown_info_str release];
        eclipse_countdown_info_str = [[NSString alloc] initWithString:@"Prepared for Eclipse"];
        [ecTimeLeftLabel setText:eclipse_countdown_info_str];
// AAB: This is redundant, because can request form control.        photo_button_is_enabled = true;
        
    }
    else
    {
        // Not within the eclipse interval.
        // Disable the photo button.
        
        // Caclulate the countdown time, and set 
// No longer done here:        [[self stillButton] setEnabled:NO];

        // AAB: This one is for testing        [[self stillButton] setEnabled:YES];

        NSCalendar *greg = [[NSCalendar alloc]
                            initWithCalendarIdentifier:NSGregorianCalendar];
        
        NSUInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
        
        NSDateComponents *components = [greg components:unitFlags
                                               fromDate:currentDate
                                                 toDate:eclipse_start_date_time options:0];
        NSInteger year_diff = [components year];
        NSInteger month_diff = [components month];
        NSInteger day_diff = [components day];
        NSInteger hour_diff = [components hour];
        NSInteger minute_diff = [components minute];
        NSInteger second_diff = [components second];
       
        [eclipse_countdown_info_str release];
        if ((second_diff < 0) || (minute_diff < 0) || (hour_diff < 0) || (day_diff < 0) || (month_diff < 0) || (year_diff < 0))
        {
            eclipse_countdown_info_str = [[NSString alloc] initWithString:@"Photo Session Complete"];
        }
        else{    
            eclipse_countdown_info_str = [[NSString alloc] initWithFormat:@"%02d:%02d:%02d %02d:%02d:%02d",year_diff,month_diff,day_diff,hour_diff,minute_diff,second_diff];
        };
        [ecTimeLeftLabel setText:eclipse_countdown_info_str];
                
        // Free the calendar used for calculations 
        // Probably better to only create one at the start of the application.
        [greg release];
#if 0   // AAB: No longer done, as handled above.  
        if ([[self stillButton] isEnabled] == YES)
        //if (photo_button_is_enabled)
        {
            // We update the location and time immediately after
            // the eclipse is over without a restart of the application.
            // This is primarily to recalculate new eclipse start and end times.

            [self updateLocation];
            [[self stillButton] setEnabled:NO]; //photo_button_is_enabled = false;
        }
#endif
    };
    };
    
    
    // Schedule the next event
    dispatch_time_t delay = dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC - 1000); // A bit less than one second
    dispatch_after(delay,dispatch_get_main_queue(),^{
        [self Countdown];
    });
    
    
}

#if 0
// For testing only when no location services available
-(void) stubLocationManager{
    
    int i;
    // Clear the cached timeZone information for this application
    [NSTimeZone resetSystemTimeZone];
    
    // NOTE: It may be better to turn these into NSNumber objects...
    // To keep it simple, we do not look at accuracy.
    
//    CLLocationCoordinate2D coordinate = [location coordinate];
    
    //  LATITUTUDE N [CHANGE HERE FOR TESTING]
    //captureManager->lat_degrees = (double) 37.7750; // San Francisco
    //captureManager->lat_degrees = (double) -33.863400; // Sydney
    captureManager->lat_degrees = (double) coordinate.latitude;    // iPhone gives N = positive
    
    //  LONGITUDE W [CHANGE HERE FOR TESTING]
    //captureManager->lon_degrees =  (double) 122.4183; // San Francisco
    //captureManager->lon_degrees = (double) 151.211000; // Sydney
    captureManager->lon_degrees = (double) coordinate.longitude; // iPhone appears to give E = positive (THIS IS CORRECT, it is the eclipse program that's screwy)
    
    //NSString * lat_degrees_info_str = [NSString stringWithFormat:@"%f",lat_degrees];
    //NSString * lon_degrees_info_str = [NSString stringWithFormat:@"%f",lat_degrees];
    
    
    // We must now stop the location service to save power
    // NOTE: It is very important to set the delegate to nil
    // It's unclear if this keeps sapping power, because messages do arrive
    // if not set to nil.
    //    [locationManager stopUpdatingLocation];
    //    [locationManager setDelegate:nil];
    
    // Get the information necessary to query the eclipse database.
    
    NSDateComponents *components = [[NSDateComponents alloc] init];
    NSCalendar *greg = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    
    // What we want is the GMT.
    NSDate * currentDate = [NSDate date];
    NSInteger offsetSecondsGMT = [[NSTimeZone systemTimeZone] secondsFromGMT];
    NSDate * currentDateGMT = [currentDate dateByAddingTimeInterval:-offsetSecondsGMT];
    
    // We now pull out the components of GMT date
    NSUInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit |NSSecondCalendarUnit;
    
    // Put back the start date
    NSDateComponents * components_GMT = [greg components:unitFlags fromDate:currentDateGMT];
    // We now pull out the GMT time
    
    int loc_year  = [components_GMT year];//timeinfo->tm_year + 1900;
    int loc_month = [components_GMT month];//timeinfo->tm_mon + 1;
    int loc_day   = [components_GMT day];//timeinfo->tm_mday;
    int loc_hr    = [components_GMT hour];//timeinfo->tm_hour;
    int loc_min   = [components_GMT minute];//timeinfo->tm_min;
    int loc_sec   = [components_GMT second];//timeinfo->tm_sec;
    
    [components release];
    [greg release];
    
    // NOTE: The output strings calculated by calc_error includes DST correction for current location on the date of the eclipse.
    int calc_error =  calc_eclipse(captureManager->lat_degrees,(- captureManager->lon_degrees), loc_month, loc_day, loc_year, loc_hr, loc_min, loc_sec);
    
    int yyyy;
    int mm_month;
    int dd;
    
    int hh;
    int mm_min;
    int ss;
    
    
    // All values strings will be updated
    // Dates may or may not, so done at point of release.
    
    [lat_degrees_info_str release];
    [lon_degrees_info_str release];
    lat_degrees_info_str = [[NSString alloc] initWithFormat:@"%f",captureManager->lat_degrees];
    lon_degrees_info_str = [[NSString alloc] initWithFormat:@"%f",captureManager->lon_degrees];
    
    // These are always set.
    [eclipse_start_time_info_str release]; 
    [eclipse_end_time_info_str release];
    
    switch(calc_error)
    {
        case ECLIPSE_ERROR_NONE:
            
            // We now have the start and end date/time of the eclipse correctly calculated in US style text
            // We need to convert both times to NSDate objects for later use (e.g. Display and difference for countdown)
            // Convert the start date first
            
            
            // Update NSDate objects for start and end of eclipse if needed
            // Update string representations of these as well.
            // This will likely need to be freed (I think)
            
            // Create the necessary objects to handle conversion.
            
            // !!!!DO NOT REMOVE THE FOLLOWING semicolon!!!!!
            // !!!! There seems to be an issue with the compiler forcing me to place the following semicolon !!!!
            ;
            
            NSDateComponents *components = [[NSDateComponents alloc] init];
            
            NSCalendar *greg = [[NSCalendar alloc]
                                initWithCalendarIdentifier:NSGregorianCalendar];
            
            //            NSUInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit |NSSecondCalendarUnit;       
            
            yyyy        = atoi(&eclipse_start_date_str[0]);
            mm_month    = atoi(&eclipse_start_date_str[5]);
            dd          = atoi(&eclipse_start_date_str[8]);
            hh          = atoi(&eclipse_start_time_str[0]);
            mm_min      = atoi(&eclipse_start_time_str[3]);
            ss          = atoi(&eclipse_start_time_str[6]);
            
            [components setDay:dd];
            [components setMonth:mm_month];
            [components setYear:yyyy];
            [components setHour:hh];
            [components setMinute:mm_min];
            [components setSecond:ss];
            
            [eclipse_start_date_time release];
            eclipse_start_date_time = [[greg dateFromComponents:components] retain];
            
            // Although end and start dates currently the same, may not be someday.
            // So, for now, we actually recalculate them.
            
            yyyy        = atoi(&eclipse_end_date_str[0]);
            mm_month    = atoi(&eclipse_end_date_str[5]);
            dd          = atoi(&eclipse_end_date_str[8]);
            hh          = atoi(&eclipse_end_time_str[0]);
            mm_min      = atoi(&eclipse_end_time_str[3]);
            ss          = atoi(&eclipse_end_time_str[6]);
            
            [components setDay:dd];
            [components setMonth:mm_month];
            [components setYear:yyyy];
            [components setHour:hh];
            [components setMinute:mm_min];
            [components setSecond:ss];
            
            [eclipse_end_date_time release];
            eclipse_end_date_time = [[greg dateFromComponents:components] retain];
            
            yyyy        = atoi(&eclipse_mid_date_str[0]);
            mm_month    = atoi(&eclipse_mid_date_str[5]);
            dd          = atoi(&eclipse_mid_date_str[8]);
            hh          = atoi(&eclipse_mid_time_str[0]);
            mm_min      = atoi(&eclipse_mid_time_str[3]);
            ss          = atoi(&eclipse_end_time_str[6]);
            
            [components setDay:dd];
            [components setMonth:mm_month];
            [components setYear:yyyy];
            [components setHour:hh];
            [components setMinute:mm_min];
            [components setSecond:ss];
            
            // NOTE: This date is not retained.
            // It is used only to fill the array of interval values, and then discarded.
            NSDate * eclipse_tmp_mid_date_time = [greg dateFromComponents:components];
            
            // Clear existing values
            for (i = 0; i < NUM_PICS; ++i){
                [eclipse_interval_start_date_time[i] release];
                [eclipse_interval_end_date_time[i] release];
            }
            
            
            // For the moment, we will allow 30 seconds to take each picture.
            eclipse_interval_start_date_time[NUM_PICS / 2] = [[eclipse_tmp_mid_date_time dateByAddingTimeInterval: -15] retain];
            eclipse_interval_end_date_time[NUM_PICS / 2] = [[eclipse_tmp_mid_date_time dateByAddingTimeInterval: 15] retain];
            
            // Fill entries on either side of center with appropriate values.
            int offset_seconds = floor((float) TIME_WINDOW_ECLIPSE / (float) (NUM_PICS / 2) + .5);
            for (i = 0; i < (NUM_PICS / 2); ++i)
            {
                eclipse_interval_start_date_time[(NUM_PICS / 2) - (i + 1)] = [[eclipse_interval_start_date_time[NUM_PICS / 2] dateByAddingTimeInterval: - (i + 1) * offset_seconds] retain];  
                
                eclipse_interval_end_date_time[(NUM_PICS / 2)- (i + 1)] = [[eclipse_interval_end_date_time[NUM_PICS / 2] dateByAddingTimeInterval: - (i + 1) * offset_seconds] retain];
                
                eclipse_interval_start_date_time[(NUM_PICS / 2) + (i + 1)] = [[eclipse_interval_start_date_time[NUM_PICS / 2] dateByAddingTimeInterval: (i + 1) * offset_seconds] retain];  
                
                eclipse_interval_end_date_time[(NUM_PICS / 2) + (i + 1)] = [[eclipse_interval_end_date_time[NUM_PICS / 2] dateByAddingTimeInterval: (i + 1) * offset_seconds] retain];
                
            }
            
            // Free up the machinery used to calculate dates
            [components release];
            [greg release];
            
            // We need to create the output strings
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
            [dateFormatter setTimeStyle:NSDateFormatterShortStyle];
            
            eclipse_start_time_info_str = [[dateFormatter stringFromDate:eclipse_start_date_time] retain];
            
            eclipse_end_time_info_str = [[dateFormatter stringFromDate:eclipse_end_date_time] retain];
            
            [dateFormatter release];
            
            is_countdown_enabled = true;
            // We have a start date and end date for the eclipse.
            // So, we should start queing messages using GCD to update times each second.
            // Note: This should only be done from here once. After this, it will
            // always be handled in Countdown.
            
            if (!countdown_started){
                countdown_started = true;
                dispatch_time_t delay = dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC - 1000); // A bit less than one second
                dispatch_after(delay,dispatch_get_main_queue(),^{
                    [self Countdown];
                });
                
            }
            break;
            
            
        case ECLIPSE_ERROR_INPUT_YEAR_OUT_OF_RANGE:
            eclipse_start_time_info_str = [[NSString alloc] initWithString:@"Current year is outside the range 2012-2035."];
            eclipse_end_time_info_str = [[NSString alloc] initWithString:@"No eclipse calculated."];
            break;
            
        case ECLIPSE_ERROR_NO_ECLIPSE_VISIBLE:
            eclipse_start_time_info_str = [[NSString alloc] initWithString:@"No eclipse visible from current location"];
            eclipse_start_time_info_str = [[NSString alloc] initWithString:@"before 2035."];
            break;    
            
        default:
            eclipse_start_time_info_str = [[NSString alloc] initWithString:@"Unexpected problem."];
            eclipse_end_time_info_str = [[NSString alloc] initWithString:@"No eclipse calculated."];
            break;
    }
    
    
    // Update the graphical representations
    [locLatInfoLabel setText:lat_degrees_info_str];
    [locLongInfoLabel setText:lon_degrees_info_str];
    [ecDateTimeStartInfoLabel setText:eclipse_start_time_info_str];
    [ecDateTimeEndInfoLabel setText:eclipse_end_time_info_str];
    
    
}
#endif

/* When the application has been restarted, it will
 * call this when a location is available.
 *
 * In this function, the eclipse start and end are calculated.
 * All interval start and end times are recalculated.
 *
 */
- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation {
    
    is_countdown_enabled = false;
// We want to grab the location, create some labels, and then stop collecting more.
// We don't want to release the service, as this is done when the app is closed.
    int i;
    // Get a location
    CLLocation *location = [locationManager location];
	if (!location) {
		return;
	}


    // Clear the cached timeZone information for this application
    [NSTimeZone resetSystemTimeZone];
    
    // NOTE: It may be better to turn these into NSNumber objects...
    // To keep it simple, we do not look at accuracy.
    
    CLLocationCoordinate2D coordinate = [location coordinate];
    
//  LATITUTUDE N [CHANGE HERE FOR TESTING]
//  captureManager->lat_degrees = (double) 37.7750; // San Francisco
//  captureManager->lat_degrees = (double) -33.863400; // Sydney
    captureManager->lat_degrees = (double) coordinate.latitude;    // iPhone gives N = positive

//  LONGITUDE E [CHANGE HERE FOR TESTING]
//  captureManager->lon_degrees =  (double) 122.4183; // San Francisco
//  captureManager->lon_degrees = (double) 151.211000; // Sydney
    captureManager->lon_degrees = (double) coordinate.longitude; // iPhone appears to give E = positive (THIS IS CORRECT, it is the eclipse program that's screwy)
    
    //NSString * lat_degrees_info_str = [NSString stringWithFormat:@"%f",lat_degrees];
    //NSString * lon_degrees_info_str = [NSString stringWithFormat:@"%f",lat_degrees];
    
    
    // We must now stop the location service to save power
    // NOTE: It is very important to set the delegate to nil
    // It's unclear if this keeps sapping power, because messages do arrive
    // if not set to nil.
    [locationManager stopUpdatingLocation];
    [locationManager setDelegate:nil];
    
    // Get the information necessary to query the eclipse database.
    
    NSDateComponents *components = [[NSDateComponents alloc] init];
    NSCalendar *greg = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    
    // What we want is the GMT.
    NSDate * currentDate = [NSDate date];
    NSInteger offsetSecondsGMT = [[NSTimeZone systemTimeZone] secondsFromGMT];
    NSDate * currentDateGMT = [currentDate dateByAddingTimeInterval:-offsetSecondsGMT];
    
    // We now pull out the components of GMT date
    NSUInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit |NSSecondCalendarUnit;
    
    // Put back the start date
    NSDateComponents * components_GMT = [greg components:unitFlags fromDate:currentDateGMT];
    // We now pull out the GMT time
    
    int loc_year  = [components_GMT year];//timeinfo->tm_year + 1900;
    int loc_month = [components_GMT month];//timeinfo->tm_mon + 1;
    int loc_day   = [components_GMT day];//timeinfo->tm_mday;
    int loc_hr    = [components_GMT hour];//timeinfo->tm_hour;
    int loc_min   = [components_GMT minute];//timeinfo->tm_min;
    int loc_sec   = [components_GMT second];//timeinfo->tm_sec;

    [components release];
    [greg release];
    
    // NOTE: The output strings calculated by calc_error includes DST correction for current location on the date of the eclipse.
    int calc_error =  calc_eclipse(captureManager->lat_degrees,(- captureManager->lon_degrees), loc_month, loc_day, loc_year, loc_hr, loc_min, loc_sec);
    
    int yyyy;
    int mm_month;
    int dd;
    
    int hh;
    int mm_min;
    int ss;
    
    
    // All values strings will be updated
    // Dates may or may not, so done at point of release.

    [lat_degrees_info_str release];
    [lon_degrees_info_str release];
    lat_degrees_info_str = [[NSString alloc] initWithFormat:@"%f",captureManager->lat_degrees];
    lon_degrees_info_str = [[NSString alloc] initWithFormat:@"%f",captureManager->lon_degrees];
    
    // These are always set.
    [eclipse_start_time_info_str release]; 
    [eclipse_end_time_info_str release];
    
    switch(calc_error)
    {
        case ECLIPSE_ERROR_NONE:
            
            // We now have the start and end date/time of the eclipse correctly calculated in US style text
            // We need to convert both times to NSDate objects for later use (e.g. Display and difference for countdown)
            // Convert the start date first

            
            // Update NSDate objects for start and end of eclipse if needed
            // Update string representations of these as well.
            // This will likely need to be freed (I think)
            
            // Create the necessary objects to handle conversion.
            
            // !!!!DO NOT REMOVE THE FOLLOWING semicolon!!!!!
            // !!!! There seems to be an issue with the compiler forcing me to place the following semicolon !!!!
            ;
            
            NSDateComponents *components = [[NSDateComponents alloc] init];

            NSCalendar *greg = [[NSCalendar alloc]
                                initWithCalendarIdentifier:NSGregorianCalendar];
            
//            NSUInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit |NSSecondCalendarUnit;       
            
            yyyy        = atoi(&eclipse_start_date_str[0]);
            mm_month    = atoi(&eclipse_start_date_str[5]);
            dd          = atoi(&eclipse_start_date_str[8]);
            hh          = atoi(&eclipse_start_time_str[0]);
            mm_min      = atoi(&eclipse_start_time_str[3]);
            ss          = atoi(&eclipse_start_time_str[6]);

            [components setDay:dd];
            [components setMonth:mm_month];
            [components setYear:yyyy];
            [components setHour:hh];
            [components setMinute:mm_min];
            [components setSecond:ss];
         
            [eclipse_start_date_time release];
            eclipse_start_date_time = [[greg dateFromComponents:components] retain];

            // Although end and start dates currently the same, may not be someday.
            // So, for now, we actually recalculate them.

            yyyy        = atoi(&eclipse_end_date_str[0]);
            mm_month    = atoi(&eclipse_end_date_str[5]);
            dd          = atoi(&eclipse_end_date_str[8]);
            hh          = atoi(&eclipse_end_time_str[0]);
            mm_min      = atoi(&eclipse_end_time_str[3]);
            ss          = atoi(&eclipse_end_time_str[6]);

            [components setDay:dd];
            [components setMonth:mm_month];
            [components setYear:yyyy];
            [components setHour:hh];
            [components setMinute:mm_min];
            [components setSecond:ss];

            [eclipse_end_date_time release];
            eclipse_end_date_time = [[greg dateFromComponents:components] retain];
           
            yyyy        = atoi(&eclipse_mid_date_str[0]);
            mm_month    = atoi(&eclipse_mid_date_str[5]);
            dd          = atoi(&eclipse_mid_date_str[8]);
            hh          = atoi(&eclipse_mid_time_str[0]);
            mm_min      = atoi(&eclipse_mid_time_str[3]);
            ss          = atoi(&eclipse_end_time_str[6]);
            
            [components setDay:dd];
            [components setMonth:mm_month];
            [components setYear:yyyy];
            [components setHour:hh];
            [components setMinute:mm_min];
            [components setSecond:ss];
            
            // NOTE: This date is not retained.
            // It is used only to fill the array of interval values, and then discarded.
            NSDate * eclipse_tmp_mid_date_time = [greg dateFromComponents:components];
            
            // Clear existing values
            for (i = 0; i < NUM_PICS; ++i){
                [eclipse_interval_start_date_time[i] release];
                [eclipse_interval_end_date_time[i] release];
            }
            
            
            // For the moment, we will allow 30 seconds to take each picture.
            eclipse_interval_start_date_time[NUM_PICS / 2] = [[eclipse_tmp_mid_date_time dateByAddingTimeInterval: -15] retain];
            eclipse_interval_end_date_time[NUM_PICS / 2] = [[eclipse_tmp_mid_date_time dateByAddingTimeInterval: 15] retain];
            
            // Fill entries on either side of center with appropriate values.
            int offset_seconds = floor((float) TIME_WINDOW_ECLIPSE / (float) (NUM_PICS / 2) + .5);
            for (i = 0; i < (NUM_PICS / 2); ++i)
            {
                eclipse_interval_start_date_time[(NUM_PICS / 2) - (i + 1)] = [[eclipse_interval_start_date_time[NUM_PICS / 2] dateByAddingTimeInterval: - (i + 1) * offset_seconds] retain];  
                
                eclipse_interval_end_date_time[(NUM_PICS / 2)- (i + 1)] = [[eclipse_interval_end_date_time[NUM_PICS / 2] dateByAddingTimeInterval: - (i + 1) * offset_seconds] retain];
                                
                eclipse_interval_start_date_time[(NUM_PICS / 2) + (i + 1)] = [[eclipse_interval_start_date_time[NUM_PICS / 2] dateByAddingTimeInterval: (i + 1) * offset_seconds] retain];  
                
                eclipse_interval_end_date_time[(NUM_PICS / 2) + (i + 1)] = [[eclipse_interval_end_date_time[NUM_PICS / 2] dateByAddingTimeInterval: (i + 1) * offset_seconds] retain];
                
            }
            
            // Free up the machinery used to calculate dates
            [components release];
            [greg release];
            
            // We need to create the output strings
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
            [dateFormatter setTimeStyle:NSDateFormatterShortStyle];
            
            eclipse_start_time_info_str = [[dateFormatter stringFromDate:eclipse_start_date_time] retain];
            
            eclipse_end_time_info_str = [[dateFormatter stringFromDate:eclipse_end_date_time] retain];
            
            [dateFormatter release];
      
            is_countdown_enabled = true;
            // We have a start date and end date for the eclipse.
            // So, we should start queing messages using GCD to update times each second.
            // Note: This should only be done from here once. After this, it will
            // always be handled in Countdown.

            if (!countdown_started){
                countdown_started = true;
                dispatch_time_t delay = dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC - 1000); // A bit less than one second
                dispatch_after(delay,dispatch_get_main_queue(),^{
                    [self Countdown];
            });

            }
            break;
        
        
        case ECLIPSE_ERROR_INPUT_YEAR_OUT_OF_RANGE:
            eclipse_start_time_info_str = [[NSString alloc] initWithString:@"Current year is outside the range 2012-2035."];
            eclipse_end_time_info_str = [[NSString alloc] initWithString:@"No eclipse calculated."];
            break;
            
        case ECLIPSE_ERROR_NO_ECLIPSE_VISIBLE:
            eclipse_start_time_info_str = [[NSString alloc] initWithString:@"No eclipse visible from current location"];
            eclipse_start_time_info_str = [[NSString alloc] initWithString:@"before 2035."];
            break;    
        
        default:
            eclipse_start_time_info_str = [[NSString alloc] initWithString:@"Unexpected problem."];
            eclipse_end_time_info_str = [[NSString alloc] initWithString:@"No eclipse calculated."];
            break;
    }

    
    // Update the graphical representations
    [locLatInfoLabel setText:lat_degrees_info_str];
    [locLongInfoLabel setText:lon_degrees_info_str];
    [ecDateTimeStartInfoLabel setText:eclipse_start_time_info_str];
    [ecDateTimeEndInfoLabel setText:eclipse_end_time_info_str];


}

// This would typically occur if a user has blocked your app from using the services.
// Or perhaps if Wi-fi isn't on on an iPod (maybe)
- (void)locationManager:(CLLocationManager *)manager 
    didFailWithError:(NSError *)error {
    // The location "unknown" error simply means the manager is currently unable to get the location.
    // We can ignore this error for the scenario of getting a single location fix, because we already have a 
    // timeout that will stop the location manager to save power.
    if ([error code] != kCLErrorLocationUnknown) {
        [locationManager stopUpdatingLocation/*:NSLocalizedString(@"Error", @"Error")*/];
        
        UIAlertView *servicesDisabledAlert = [[UIAlertView alloc] initWithTitle:@"Location Services Disabled" message:@"To obtain accurate eclipse times, location services should be enabled for this application using the Settings app." delegate:nil cancelButtonTitle:@"Cancel" otherButtonTitles:nil];
        [servicesDisabledAlert show];
        [servicesDisabledAlert release];

    }
}


- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if (context == AVCamFocusModeObserverContext) {
        // Update the focus UI overlay string when the focus mode changes
		[focusModeLabel setText:[NSString stringWithFormat:@"focus: %@", [self stringForFocusMode:(AVCaptureFocusMode)[[change objectForKey:NSKeyValueChangeNewKey] integerValue]]]];
	} else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

#pragma mark Toolbar Actions
- (IBAction)captureStillImage:(id)sender
{
    // Capture a still image
    // Disable button while capturing.
    [[self stillButton] setEnabled:NO];
    is_processing_picture = true;
        
    // Camera settings (ISO/ Exposure) have been set and locked prior to photo.
    photoCount = NUM_PHOTOS_PER_CLICK;
    [[self captureManager] captureStillImage]; // Assumed to work. returns void.
#if 0
    // NOTE: This may slow things down.
    // Flash the screen black and fade it out to give UI feedback that a still image was taken
    UIView *flashView = [[UIView alloc] initWithFrame:[[self videoPreviewView] frame]];
    [flashView setBackgroundColor:[UIColor blackColor]];
    [[[self view] window] addSubview:flashView];
    
    [UIView animateWithDuration:.4f
                     animations:^{
                         [flashView setAlpha:0.f];
                     }
                     completion:^(BOOL finished){
                         [flashView removeFromSuperview];
                         [flashView release];
                     }
     ];
#endif
    
    // User will be unable to take a picture until next interval.
    camera_state = INSIDE_WINDOW_EXP_ADJUSTED_PIC_COMPLETE_BUTTON_DISABLED;
}

@end

@implementation AVCamViewController (InternalMethods)

// Convert from view coordinates to camera coordinates, where {0,0} represents the top left of the picture area, and {1,1} represents
// the bottom right in landscape mode with the home button on the right.
- (CGPoint)convertToPointOfInterestFromViewCoordinates:(CGPoint)viewCoordinates 
{
    CGPoint pointOfInterest = CGPointMake(.5f, .5f);
    CGSize frameSize = [[self videoPreviewView] frame].size;
    
    if ([captureVideoPreviewLayer isMirrored]) {
        viewCoordinates.x = frameSize.width - viewCoordinates.x;
    }    

    if ( [[captureVideoPreviewLayer videoGravity] isEqualToString:AVLayerVideoGravityResize] ) {
		// Scale, switch x and y, and reverse x
        pointOfInterest = CGPointMake(viewCoordinates.y / frameSize.height, 1.f - (viewCoordinates.x / frameSize.width));
    } else {
        CGRect cleanAperture;
        for (AVCaptureInputPort *port in [[[self captureManager] videoInput] ports]) {
            if ([port mediaType] == AVMediaTypeVideo) {
                cleanAperture = CMVideoFormatDescriptionGetCleanAperture([port formatDescription], YES);
                CGSize apertureSize = cleanAperture.size;
                CGPoint point = viewCoordinates;

                CGFloat apertureRatio = apertureSize.height / apertureSize.width;
                CGFloat viewRatio = frameSize.width / frameSize.height;
                CGFloat xc = .5f;
                CGFloat yc = .5f;
                
                if ( [[captureVideoPreviewLayer videoGravity] isEqualToString:AVLayerVideoGravityResizeAspect] ) {
                    if (viewRatio > apertureRatio) {
                        CGFloat y2 = frameSize.height;
                        CGFloat x2 = frameSize.height * apertureRatio;
                        CGFloat x1 = frameSize.width;
                        CGFloat blackBar = (x1 - x2) / 2;
						// If point is inside letterboxed area, do coordinate conversion; otherwise, don't change the default value returned (.5,.5)
                        if (point.x >= blackBar && point.x <= blackBar + x2) {
							// Scale (accounting for the letterboxing on the left and right of the video preview), switch x and y, and reverse x
                            xc = point.y / y2;
                            yc = 1.f - ((point.x - blackBar) / x2);
                        }
                    } else {
                        CGFloat y2 = frameSize.width / apertureRatio;
                        CGFloat y1 = frameSize.height;
                        CGFloat x2 = frameSize.width;
                        CGFloat blackBar = (y1 - y2) / 2;
						// If point is inside letterboxed area, do coordinate conversion. Otherwise, don't change the default value returned (.5,.5)
                        if (point.y >= blackBar && point.y <= blackBar + y2) {
							// Scale (accounting for the letterboxing on the top and bottom of the video preview), switch x and y, and reverse x
                            xc = ((point.y - blackBar) / y2);
                            yc = 1.f - (point.x / x2);
                        }
                    }
                } else if ([[captureVideoPreviewLayer videoGravity] isEqualToString:AVLayerVideoGravityResizeAspectFill]) {
					// Scale, switch x and y, and reverse x
                    if (viewRatio > apertureRatio) {
                        CGFloat y2 = apertureSize.width * (frameSize.width / apertureSize.height);
                        xc = (point.y + ((y2 - frameSize.height) / 2.f)) / y2; // Account for cropped height
                        yc = (frameSize.width - point.x) / frameSize.width;
                    } else {
                        CGFloat x2 = apertureSize.height * (frameSize.height / apertureSize.width);
                        yc = 1.f - ((point.x + ((x2 - frameSize.width) / 2)) / x2); // Account for cropped width
                        xc = point.y / frameSize.height;
                    }
                }
                
                pointOfInterest = CGPointMake(xc, yc);
                break;
            }
        }
    }
    
    return pointOfInterest;
}

// Auto focus at a particular point. The focus mode will change to locked once the auto focus happens.
- (void)tapToAutoFocus:(UIGestureRecognizer *)gestureRecognizer
{
    if ([[[captureManager videoInput] device] isFocusPointOfInterestSupported]) {
        CGPoint tapPoint = [gestureRecognizer locationInView:[self videoPreviewView]];
        CGPoint convertedFocusPoint = [self convertToPointOfInterestFromViewCoordinates:tapPoint];
        [captureManager autoFocusAtPoint:convertedFocusPoint];
    }
}

// Change to continuous auto focus. The camera will constantly focus at the point choosen.
- (void)tapToContinouslyAutoFocus:(UIGestureRecognizer *)gestureRecognizer
{
    if ([[[captureManager videoInput] device] isFocusPointOfInterestSupported])
        [captureManager continuousFocusAtPoint:CGPointMake(.5f, .5f)];
}

// Update button states based on the number of available cameras and mics
// Note: This gets called on startup and on configuration change.
//       May conflict with other settings, as controls same button state.
//       Once each second would gets overridden.
//       This means, it could get turned on, eventhough busy taking a picture.
//       That is not what should happen.
//       
//       Must therefore add both states.
//       One = Taking photo
//       Other = Inside interval


// No longer set button states here.
// Now only set is_camera_present
- (void)updateButtonStates
{
	NSUInteger cameraCount = [[self captureManager] cameraCount];
    
    CFRunLoopPerformBlock(CFRunLoopGetMain(), kCFRunLoopCommonModes, ^(void) {
        
            if (cameraCount < 1) {
                is_camera_present = false;
#if 0                
                [[self stillButton] setEnabled:NO];
                // AAB: Throw an error of some sort.
                // NOTE: Perhaps there is a way to do this calling didFailWithError.
#endif
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"No Camera", @"No camera")
                                                                    message:NSLocalizedString(@"No camera is available to take pictures. The photo button will therefore be disabled.", @"No camera is available. Photo button disabled.")
                                                                   delegate:nil
                                                          cancelButtonTitle:NSLocalizedString(@"OK", @"OK button title")
                                                          otherButtonTitles:nil];
                [alertView show];
                [alertView release];
            
            } else {
                
                is_camera_present = true;
#if 0
                if ((true == is_camera_present) &&
                    (true == is_inside_interval) && 
                    (false == is_processing_picture))
                    [[self stillButton] setEnabled:YES];
                else
                    [[self stillButton] setEnabled:NO];
#endif

            }

    });
}

@end

@implementation AVCamViewController (AVCamCaptureManagerDelegate)

- (void)captureManager:(AVCamCaptureManager *)captureManager didFailWithError:(NSError *)error
{
    CFRunLoopPerformBlock(CFRunLoopGetMain(), kCFRunLoopCommonModes, ^(void) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[error localizedDescription]
                                                            message:[error localizedFailureReason]
                                                           delegate:nil
                                                  cancelButtonTitle:NSLocalizedString(@"OK", @"OK button title")
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    });
}

- (void)captureManagerRecordingBegan:(AVCamCaptureManager *)captureManager
{
//    CFRunLoopPerformBlock(CFRunLoopGetMain(), kCFRunLoopCommonModes, ^(void) {
//        [[self recordButton] setTitle:NSLocalizedString(@"Stop", @"Toggle recording button stop title")];
//        [[self recordButton] setEnabled:YES];
//    });
}

- (void)captureManagerRecordingFinished:(AVCamCaptureManager *)captureManager
{
//    CFRunLoopPerformBlock(CFRunLoopGetMain(), kCFRunLoopCommonModes, ^(void) {
//        [[self recordButton] setTitle:NSLocalizedString(@"Record", @"Toggle recording button record title")];
//        [[self recordButton] setEnabled:YES];
//    });
}

- (void)captureManagerStillImageCaptured:(AVCamCaptureManager *)captureManager
{
    CFRunLoopPerformBlock(CFRunLoopGetMain(), kCFRunLoopCommonModes, ^(void) {
        
        --photoCount;
        if (0 == photoCount){
        
        is_processing_picture = false;
#if 0
// Can be placed here if want a single flash
            // This might be pushed into the finish part to speed things up.
            // Flash the screen black and fade it out to give UI feedback that a still image was taken
            UIView *flashView = [[UIView alloc] initWithFrame:[[self videoPreviewView] frame]];
            [flashView setBackgroundColor:[UIColor blackColor]];
            [[[self view] window] addSubview:flashView];
            
            [UIView animateWithDuration:.4f
                             animations:^{
                                 [flashView setAlpha:0.f];
                             }
                             completion:^(BOOL finished){
                                 [flashView removeFromSuperview];
                                 [flashView release];
                             }
             ];
#endif
        }
        else
            [[self captureManager] captureStillImage];
#if 0
        if ((true == is_camera_present) &&
            (true == is_inside_interval) &&
            (false == is_processing_picture)
            )
            [[self stillButton] setEnabled:YES];
       else
           [[self stillButton] setEnabled:NO];
#endif
    });

}

- (void)captureManagerDeviceConfigurationChanged:(AVCamCaptureManager *)captureManager
{
    
    // AAB: This could get called, and confuse issues.
	[self updateButtonStates];
}


@end
