//
//  ecalc_extern.h
//  AVCam05
//
//  Created by A B on 9/29/12.
//
/*
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 
 Copyright (C) Adrian Buriks 2012
 */

#ifndef ecalc_extern_h
#define ecalc_extern_h

// These need to be available outside the function

#define ECLIPSE_ERROR_NONE 0
#define ECLIPSE_ERROR_INPUT_YEAR_OUT_OF_RANGE 1
#define ECLIPSE_ERROR_NO_ECLIPSE_VISIBLE 2


extern int eclipseError; // Codes to report various errors during calculation


extern bool is_eclipse_visible; // This means: Will the eclipse be visible now, or in the future

int dst_offset_hours; // This is an amount we must add to the hours value to get the right result.
                      // It cannot be determined until we have both the location and date of eclipse.

extern double eclipse_start_date_julian;
extern double eclipse_end_date_julian;

extern char eclipse_start_date_str[20];
extern char eclipse_start_time_str[20];

extern char eclipse_mid_date_str[20];
extern char eclipse_mid_time_str[20];

extern char eclipse_end_date_str[20]; // Note: We likely won't need this, but copy anyway
extern char eclipse_end_time_str[20];


extern int calc_eclipse(double latitude,  // +N, -S (this is the same as iphone provides)
                            double longitude, // +W, -E (this is reverse of what iPhone provides)
                            
                            // This is today's date. We calculate forwards from here to find Eclipses.
                            int month, // 1 - 12
                            int day,   // date of month
                            int year,  // 4 digit year (I guess)
                            
                            int hour,  // This is the current time at our location
                            int min,   // It is used in the final step to determine whether 
                            int sec   // we are past the eclipse.
                            // If so, a match at the current day is ruled out,
                            // and the search continues until the next eclipse.
                            // This is to fix the issue that after an eclipse,
                            // we continue to count negatively.
                            
                            //int offsetSecondsGMTInput // This is the number of seconds offset from GMT
                            // in seconds at the current location.
                            // Due to daylight savings time, it may be
                            // different than on the day of the eclipse.
                            // If it is, then the time used to determine if
                            // we are past a particular eclipse on the same
                            // day must be adjusted by this amount prior to
                            // end time comparison.
                            
                            // NOTE: We don't want to get GMT, and convert.
                            // The reason is, we could get the wrong day.
                            // However, if an eclipse is visible, we're not near midnight.
                            // Thus, we can simply add or subtract the hour as needed.
                            
                            // The time zone will need to be calculated using longitude and latitude.
                            // This can be added or subtracted later.
                            
                            // The current offset from GMT
                            //int tz_hr,    // 1 - 14              
                            //int tz_min /*, */   // (0, 15, 30, 45)
                            
                            // No longer used
                            //int tz_direction, // -1, 1 (-1 = +GMT, 1 = -GMT
                            
                            
                            // Here, we will always pass a 0. This will be adjusted using Adrian API's later.
                            //int dl_savings    // 0 = Winter, 1 = summer
                            // Will always be called with 0, and adjusted afterwards
                        );

#endif
