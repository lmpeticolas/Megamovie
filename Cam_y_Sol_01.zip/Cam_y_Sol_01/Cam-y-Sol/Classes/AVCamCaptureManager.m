/*
     File: AVCamCaptureManager.m
 Abstract: Uses the AVCapture classes to capture video and still images.
  Version: 1.2
 
 */

/*
 
 Copyright (C) Adrian Buriks 2012
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 
 Copyright (C) Adrian Buriks 2012
 
 */

#import "AVCamCaptureManager.h"
#import "AVCamUtilities.h"
#import <MobileCoreServices/UTCoreTypes.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <ImageIO/CGImageProperties.h>
#import <ImageIO/CGImageSource.h>



#pragma mark -
@interface AVCamCaptureManager (InternalUtilityMethods)
- (AVCaptureDevice *) cameraWithPosition:(AVCaptureDevicePosition)position;
- (AVCaptureDevice *) backFacingCamera;
@end


#pragma mark -
@implementation AVCamCaptureManager

@synthesize session;
@synthesize orientation;
@synthesize videoInput;
@synthesize stillImageOutput;
@synthesize deviceConnectedObserver;
@synthesize deviceDisconnectedObserver;
@synthesize backgroundRecordingID;
@synthesize delegate;

- (id) init
{
    // Init the parent class
    self = [super init];
    
    if (self != nil) {
		__block id weakSelf = self;
        
        // Create a block to handle data from a connected device
        void (^deviceConnectedBlock)(NSNotification *) = ^(NSNotification *notification) {
			
            AVCaptureDevice *device = [notification object];
			
			BOOL sessionHasDeviceWithMatchingMediaType = NO;
			NSString *deviceMediaType = nil;
			
            // Need a video stream for the preview layer
            if ([device hasMediaType:AVMediaTypeVideo])
                deviceMediaType = AVMediaTypeVideo;
			
			if (deviceMediaType != nil) {
				for (AVCaptureDeviceInput *input in [session inputs])
				{
					if ([[input device] hasMediaType:deviceMediaType]) {
						sessionHasDeviceWithMatchingMediaType = YES;
						break;
					}
				}
				
				if (!sessionHasDeviceWithMatchingMediaType) {
					NSError	*error;
					AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
					if ([session canAddInput:input])
						[session addInput:input];
				}				
			}
            
			if ([delegate respondsToSelector:@selector(captureManagerDeviceConfigurationChanged:)]) {
				[delegate captureManagerDeviceConfigurationChanged:self];
			}			
        };
        
        // Create a block for hanlding disconnections from devices
        void (^deviceDisconnectedBlock)(NSNotification *) = ^(NSNotification *notification) {
			AVCaptureDevice *device = [notification object];

            if ([device hasMediaType:AVMediaTypeVideo]) {
				[session removeInput:[weakSelf videoInput]];
				[weakSelf setVideoInput:nil];
			}
			
			if ([delegate respondsToSelector:@selector(captureManagerDeviceConfigurationChanged:)]) {
				[delegate captureManagerDeviceConfigurationChanged:self];
			}			
        };
        
        // Get the data block notifications
        NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
        
        [self setDeviceConnectedObserver:[notificationCenter addObserverForName:AVCaptureDeviceWasConnectedNotification object:nil queue:nil usingBlock:deviceConnectedBlock]];
        [self setDeviceDisconnectedObserver:[notificationCenter addObserverForName:AVCaptureDeviceWasDisconnectedNotification object:nil queue:nil usingBlock:deviceDisconnectedBlock]];
		
        // Get device orientation notifications
        [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
        [notificationCenter addObserver:self selector:@selector(deviceOrientationDidChange) name:UIDeviceOrientationDidChangeNotification object:nil];
		orientation = AVCaptureVideoOrientationPortrait;
    }
    
    return self;
}

- (void) dealloc
{
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    
    [notificationCenter removeObserver:[self deviceConnectedObserver]];
    [notificationCenter removeObserver:[self deviceDisconnectedObserver]];
	[notificationCenter removeObserver:self name:UIDeviceOrientationDidChangeNotification object:nil];
	[[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];
    
    [[self session] stopRunning];
    
    [self->unique_id release];
    [session release];
    [videoInput release];
    [stillImageOutput release];
    
    [super dealloc];
}

- (BOOL) setupSession
{
    BOOL success = NO;
    
	// Turn off the flash and torch if present
	if ([[self backFacingCamera] hasFlash]) {
		if ([[self backFacingCamera] lockForConfiguration:nil]) {
			if ([[self backFacingCamera] isFlashModeSupported:AVCaptureFlashModeAuto]) {
				[[self backFacingCamera] setFlashMode:AVCaptureFlashModeOff];
			}
			[[self backFacingCamera] unlockForConfiguration];
		}
	}
	if ([[self backFacingCamera] hasTorch]) {
		if ([[self backFacingCamera] lockForConfiguration:nil]) {
			if ([[self backFacingCamera] isTorchModeSupported:AVCaptureTorchModeAuto]) {
				[[self backFacingCamera] setTorchMode:AVCaptureTorchModeOff];
			}
			[[self backFacingCamera] unlockForConfiguration];
		}
	}
	
    // Init the device inputs - Needed to display what user sees.
    AVCaptureDeviceInput *newVideoInput = [[AVCaptureDeviceInput alloc] initWithDevice:[self backFacingCamera] error:nil];
    

    // AAB: This is not what we want. Need to initalize with 420f. Do that later when ready.
    // Setup the still image file output
    AVCaptureStillImageOutput *newStillImageOutput = [[AVCaptureStillImageOutput alloc] init];
    
    NSDictionary *outputSettings = [[NSDictionary alloc] initWithObjectsAndKeys:
                                    AVVideoCodecJPEG, AVVideoCodecKey,
                                    nil];
    [newStillImageOutput setOutputSettings:outputSettings];
    
    [outputSettings release];
    
    
    // Create session (use default AVCaptureSessionPresetHigh)
    AVCaptureSession *newCaptureSession = [[AVCaptureSession alloc] init];
    
    
    // Add inputs and output to the capture session

    if ([newCaptureSession canAddInput:newVideoInput]) {
        [newCaptureSession addInput:newVideoInput];
    }

    if ([newCaptureSession canAddOutput:newStillImageOutput]) {
        [newCaptureSession addOutput:newStillImageOutput];
    }
    
    // Set the variables of this object to those just created
    [self setStillImageOutput:newStillImageOutput];

    [self setVideoInput:newVideoInput];

    [self setSession:newCaptureSession];
    
    // Free up the storage used to create the setup
    [newStillImageOutput release];

    [newVideoInput release];

    [newCaptureSession release];
	
    success = YES;
    
    return success;
}

- (void) captureStillImage
{
    AVCaptureConnection *stillImageConnection = [AVCamUtilities connectionWithMediaType:AVMediaTypeVideo fromConnections:[[self stillImageOutput] connections]];
    if ([stillImageConnection isVideoOrientationSupported])
        [stillImageConnection setVideoOrientation:orientation];
    

    // THIS IS ALL RUN IN A BLOCK
    
    [[self stillImageOutput] captureStillImageAsynchronouslyFromConnection:stillImageConnection
         completionHandler:^(CMSampleBufferRef imageDataSampleBuffer, NSError *error) {
             
             // Completion block to handle failures. Will send message later.
             ALAssetsLibraryWriteImageCompletionBlock completionBlock = ^(NSURL *assetURL, NSError *error) {
                 if (error) {
                     if ([[self delegate] respondsToSelector:@selector(captureManager:didFailWithError:)]) {
                         [[self delegate] captureManager:self didFailWithError:error];
                         }
                 }
             };
             
             // Note: This gets a dictionary, but it can't be changed as it is NSData
             // This is fixed by converting it to a Mutable dictionary (as described in other sample code)
             // Once it is mutable, other fields can be added.
             if (imageDataSampleBuffer != NULL) {
                 
                 // This EXIF/GPS data appears to work with at least the following:
                 
                 // Exif: 
                 //     OriginalDateTime
                 // GPS:
                 //     Latitude:       Degrees
                 //     Longitude:      Degrees
                 //     LatitudeRef:    N/S
                 //     Longitude_REF:  W/E
                 // 

                 // Additional fields are filled here, but this is just out of concern that code may not work
                 // if fields are left missing.
                 
                 // NOTE: It's hard to tell whether any GPS timestamp information is making it into th images.
                 //       For safety, it will also be put in as the original time (EXIF) as UTC.
                 
                 NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageDataSampleBuffer];
                 ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];                 
                 
                 CGImageSourceRef  source ;
                 source = CGImageSourceCreateWithData((CFDataRef)imageData, NULL);
                 
                 //get all the metadata in the image
                 NSDictionary *metadata = (NSDictionary *) CGImageSourceCopyPropertiesAtIndex(source,0,NULL);
                 
                 //Create a mutable metadata dictionary so we can add properties to it
                 NSMutableDictionary *metadataAsMutable = [[metadata mutableCopy]autorelease];
                 
                 // Allow original one to be released
                 // PERHAPS THIS SHOULD BE DONE LATER!????
                 [metadata release];
                 
                 // Get the EXIF data
                 NSMutableDictionary *EXIFDictionary = [[[metadataAsMutable objectForKey:(NSString *)kCGImagePropertyExifDictionary]mutableCopy]autorelease];
                 
                 // Get the GPS data
                 NSMutableDictionary *gps = [[[metadataAsMutable objectForKey:(NSString *)kCGImagePropertyGPSDictionary]mutableCopy]autorelease];
                 
                 // Get the TIFF data
                 NSMutableDictionary *TIFFDictionary = [[[metadataAsMutable objectForKey:(NSString *)kCGImagePropertyTIFFDictionary]mutableCopy]autorelease];
                 
                 // IN general, the GPS doesn't exist, while the others do.
                 if(!EXIFDictionary) {
                     EXIFDictionary = [NSMutableDictionary dictionary];
                 }
                 
                 if(!gps) {
                     gps = [NSMutableDictionary dictionary];
                 }
                 
                 if(!TIFFDictionary) {
                     TIFFDictionary = [NSMutableDictionary dictionary];
                 }

                     
                 //NSMutableDictionary *gps = [NSMutableDictionary dictionary];
                 NSDate * timestamp = [NSDate date];
                 
                 // GPS tag version
                 [gps setObject:@"2.2.0.0" forKey:(NSString *)kCGImagePropertyGPSVersion];
                 
                 // Time and date must be provided as strings, not as an NSDate object it is claimed.
                 NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                 [formatter setDateFormat:@"HH:mm:ss.SSSSSS"]; 
                 [formatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
                 [gps setObject:[formatter stringFromDate:timestamp] forKey:(NSString *)kCGImagePropertyGPSTimeStamp];
                 [formatter setDateFormat:@"yyyy:MM:dd"];
                 [gps setObject:[formatter stringFromDate:timestamp] forKey:(NSString *)kCGImagePropertyGPSDateStamp];
    
                 // Attempt to set these to UTC time. It appears to work for the EXIF one.
                 [formatter setDateFormat:@"yyyy:MM:dd HH:mm:ss"];
                 [EXIFDictionary setObject:[formatter stringFromDate:timestamp] forKey:(NSString*)kCGImagePropertyExifDateTimeOriginal];
                 
                 // Adding this appears to corrupt the image. Perhaps it needs to be unicode.
                 //[EXIFDictionary setObject:unique_id forKey:(NSString*)kCGImagePropertyExifUserComment];
                 
                 [TIFFDictionary setObject:[formatter stringFromDate:timestamp] forKey:(NSString*)kCGImagePropertyTIFFDateTime];
                 [TIFFDictionary setObject:unique_id forKey:(NSString*)kCGImagePropertyTIFFImageDescription];
                 // Done using the formatter.
                 [formatter release];
                 
                 // NOTE: This has been tested to show correct S/N and W/E looking at info in iPhoto.
                 // Latitude
                 CGFloat latitude = lat_degrees; //latitude = location.coordinate.latitude;
                 if (latitude < 0) {
                     latitude = -latitude;
                     [gps setObject:@"S" forKey:(NSString *)kCGImagePropertyGPSLatitudeRef];
                 } else {
                     [gps setObject:@"N" forKey:(NSString *)kCGImagePropertyGPSLatitudeRef];
                 }
                 [gps setObject:[NSNumber numberWithFloat:latitude] forKey:(NSString *)kCGImagePropertyGPSLatitude];
                 
                 // Longitude
                 CGFloat longitude = lon_degrees; //location.coordinate.longitude;
                 if (longitude < 0) {
                     longitude = -longitude;
                     [gps setObject:@"W" forKey:(NSString *)kCGImagePropertyGPSLongitudeRef];
                 } else {
                     [gps setObject:@"E" forKey:(NSString *)kCGImagePropertyGPSLongitudeRef];
                 }
                 [gps setObject:[NSNumber numberWithFloat:longitude] forKey:(NSString *)kCGImagePropertyGPSLongitude];
                 
                 // Altitude
                 CGFloat altitude = 0.0; //location.altitude;
                 if (!isnan(altitude)){
                     if (altitude < 0) {
                         altitude = -altitude;
                         [gps setObject:@"1" forKey:(NSString *)kCGImagePropertyGPSAltitudeRef];
                     } else {
                         [gps setObject:@"0" forKey:(NSString *)kCGImagePropertyGPSAltitudeRef];
                     }
                     [gps setObject:[NSNumber numberWithFloat:altitude] forKey:(NSString *)kCGImagePropertyGPSAltitude];
                 }
                 
                // Speed, must be converted from m/s to km/h
                CGFloat speed = 0.0; 
                if (speed >= 0){
                     [gps setObject:@"K" forKey:(NSString *)kCGImagePropertyGPSSpeedRef];
                     [gps setObject:[NSNumber numberWithFloat:speed*3.6] forKey:(NSString *)kCGImagePropertyGPSSpeed];
                 }
                 
                 // Heading
                 CGFloat course = 0.0;
                 if (course >= 0){
                     [gps setObject:@"T" forKey:(NSString *)kCGImagePropertyGPSTrackRef];
                     [gps setObject:[NSNumber numberWithFloat:course] forKey:(NSString *)kCGImagePropertyGPSTrack];
                 }
                 
                 
                 // What we find is that we can now initialize with orientation...but...we've been instructed to do it
                 // using the metadata instead.
                 //
                 // Additional issue...must free stuff

                 // NOTE: This reads it into a UIImage, and then writes to library.
                 // I suspect, this will destroy the EXIF data. To avoid this, refer to example notes on website.    
                 UIImage *image = [[UIImage alloc] initWithData:imageData];
                 
                 int orient = (ALAssetOrientation)[image imageOrientation];
                 
                 int o = 1;
                 switch (orient) {
                     case UIImageOrientationUp:
                         o = 1;
                         break;
                         
                     case UIImageOrientationDown:
                         o = 3;
                         break;
                         
                     case UIImageOrientationLeft:
                         o = 8;
                         break;
                         
                     case UIImageOrientationRight:
                         o = 6;
                         break;
                         
                     case UIImageOrientationUpMirrored:
                         o = 2;
                         break;
                         
                     case UIImageOrientationDownMirrored:
                         o = 4;
                         break;
                         
                     case UIImageOrientationLeftMirrored:
                         o = 5;
                         break;
                         
                     case UIImageOrientationRightMirrored:
                         o = 7;
                         break;
                 }

                 
                 // Set the orientation correctly using the above code to get the value.
                 [metadataAsMutable setObject:[NSNumber numberWithInt:o] forKey:(NSString*)kCGImagePropertyOrientation];
              
                 // Add the sub-dictionaries back to the main dictionary.
                 [metadataAsMutable setObject:EXIFDictionary forKey:(NSString *)kCGImagePropertyExifDictionary];
                 [metadataAsMutable setObject:gps forKey:(NSString *)kCGImagePropertyGPSDictionary];
                 [metadataAsMutable setObject:TIFFDictionary forKey:(NSString *)kCGImagePropertyTIFFDictionary];
                 
                 [library writeImageToSavedPhotosAlbum:[image CGImage]
                                           //Setting the orientation this way is another call, so we do it immediately before
                                           //orientation:(ALAssetOrientation)[image imageOrientation]
                                              metadata:metadataAsMutable
                                       completionBlock:completionBlock];
                 [image release];
                 
                 [library release];
                 
                 //[lat_ref release];
                 //[lon_ref release];

                 //[date_formatter release];   
                 //[time_formatter release];
                 //[date_time_formatter release];
                 
                 // ALREADY DONE EARLIER[formatter release];

                 CFRelease(source);  // Strange it's done this way.
                 
             }
             else
                 completionBlock(nil, error);
             
             if ([[self delegate] respondsToSelector:@selector(captureManagerStillImageCaptured:)]) {
                 [[self delegate] captureManagerStillImageCaptured:self];
             }
         }]; // END OF THE BLOCK
}


#pragma mark Device Counts
- (NSUInteger) cameraCount
{
    return [[AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo] count];
}


#pragma mark Camera Properties

//
// One approach is to ratched up the gain or exposure time as follows:

// Option 1: Increase exposure
// Put finger over lense, and lock only exposure (this will be a long exposure)
// Go to whitest part with flash and lock only white balance. (This will reduce the gain)
// Put finger in front, and lock only exposure. (this will be a longer exposure as gain was reduced)
// Go to whitest part, and lock only white balance. (This will be an even lower gain)

// Alternative: Increase gain
// Put finger over lense, and lock white balance gain (This will be a high gain)
// Focus on whitest part, and lock exposure (This will be a relatively short exposure)
// Put finger over lense, and lock white balance. (This will be a higher gain)
// Focus on whitest part, and lock exposure (This will be an even shorter exposure)
// Put finger over lense, and lock white balance. (This will be an even higher gain)

// This might be tested with the original AVCAM 1.0 (Nope: No EXIF...darn)


// Issue: Might well have maxed out after first cycle.


// How will this work? Assume black rectangle at the center)
// But, it's too dark to see it at night.

// Test #1 = Check that all necessary features are available
//           before even trying this. 

// Features required = pointOfInterstExposure, pointOfInterestWhiteBalance, torch (optional), boost (optional)
// set bestError = 100K (or some such value)

// Clear array of 10 values
// Point of interest = (.5,.5)
// center = .5,.5

//    Grab configuration
//    if (boostAvailable) turn off the boost - Do not use this yet
//
//    if (torch/flash available) turn on the torch/flash
//    set White balance to Auto at center
//    set Exposure to Auto at center
//    After adjust, 
//       Lock Exposure only
//    Free configuration


//    With a single value for exposure locked...

//    Do this some number of times (N = 10)
//      Obtain control configuration
//      Enable flash/torch (So there is enough light outside in the dark)
//      Set WhiteBalance at pointOfInterest
//      Lock White balance
//      Release control of configuration (presumably this is now set)
//      Take a picture
//      Read the EXIF data (ISO value) and store this value
//      Discard the picture (if required)
//    End Do
//
//    In theory, we now have a curve of gains for a fixed exposure.
//    Trouble is...they're for a long exposure.
//    Alterntive, is begin at the maximum brightness with flash, and lock exposure.
//    On iOS 6, enable the the dimmest torch, then move towards the center.
//    Alternatively with a very dim but constant light.
//    This provides a curve of reasonably high gains...though not as high as possible...but at least the're known.
//    
//    The issue seems to be...you will need some light to create settings.
//    You want this to be very little light, so that gains are high -> fast shutter speeds.

//    Go to the brightest point, and lock the exposure.
//    Then go to the point on the gain curve, and set the gain.
//    In theory, you'll now get a boosted gain curve, but with the same shape.
//
//
//    Turn on the boost (if available)
//    With finger over (i.e. as dark as possible)
//    Take a picture and measure the ISO    
//   
//    This is the highest ISO that will be used for photos.
//    This is also likely the longest exposure.
//
//    Prior to every picture, we will do the following:
//
//    Have person hold up the card.
//    Turn on the flash
//    Camera moves point of interest to appropriate distance from center
//    Lock white balance.
//    Put finger over lense
//    Camera locks exposure.




// -- We now have a curve of ISO (i.e. Gain) at various distances from the center.

// 
 
//    We note that as Exposure was fixed, at each point as we move outwards, the ISO = gain will decrease.
//    For each point, we thus know the ratio of Gain at point / Gain at center
//
//    If we now turn off the light and measure the gains again, we get a curve of the ISO values
//    we'll likely get looking at the dark sky.
//
//    So, now we first return to the center, and lock there one more time with the torch on.
//    
//
// Set opint of interest = .5,.5
// Repeat the first measurement above.
// 
//
// if (torch available) turn it off
// if (boost available) turn it on - Not yet
// Obtain control of configuration
// Set point of interest to center
// Set exposure

//   

//    Release configuration
// if (boostAvailable) turn on the boost - Do not use this yet

// if (torch available) Turn on the torch
//    
// Grab control of configuration
// Set point of interest to bestPoint
// Set WhiteBalance
// Lock White balance
// Release configuration

// if (torch available) turn off the torch.

// BEEP (To signify ready to take picture)

// Now do the normal picture thing.


// Perform an auto focus at the specified point. The focus mode will automatically change to locked once the auto focus is complete.
- (void) autoFocusAtPoint:(CGPoint)point
{
    AVCaptureDevice *device = [[self videoInput] device];
    if ([device isFocusPointOfInterestSupported] && [device isFocusModeSupported:AVCaptureFocusModeAutoFocus]) {
        NSError *error;
        if ([device lockForConfiguration:&error]) {
            [device setFocusPointOfInterest:point];
            [device setFocusMode:AVCaptureFocusModeAutoFocus];
            [device unlockForConfiguration];
        } else {
            if ([[self delegate] respondsToSelector:@selector(captureManager:didFailWithError:)]) {
                [[self delegate] captureManager:self didFailWithError:error];
            }
        }        
    }
}

// Switch to continuous auto focus mode at the specified point
- (void) continuousFocusAtPoint:(CGPoint)point
{
    AVCaptureDevice *device = [[self videoInput] device];
	
    if ([device isFocusPointOfInterestSupported] && [device isFocusModeSupported:AVCaptureFocusModeContinuousAutoFocus]) {
		NSError *error;
		if ([device lockForConfiguration:&error]) {
			[device setFocusPointOfInterest:point];
			[device setFocusMode:AVCaptureFocusModeContinuousAutoFocus];
			[device unlockForConfiguration];
		} else {
			if ([[self delegate] respondsToSelector:@selector(captureManager:didFailWithError:)]) {
                [[self delegate] captureManager:self didFailWithError:error];
			}
		}
	}
}

@end

#pragma mark -
@implementation AVCamCaptureManager (InternalUtilityMethods)

// Keep track of current device orientation so it can be applied to movie recordings and still image captures
- (void)deviceOrientationDidChange
{	
	UIDeviceOrientation deviceOrientation = [[UIDevice currentDevice] orientation];
    
	if (deviceOrientation == UIDeviceOrientationPortrait)
		orientation = AVCaptureVideoOrientationPortrait;
	else if (deviceOrientation == UIDeviceOrientationPortraitUpsideDown)
		orientation = AVCaptureVideoOrientationPortraitUpsideDown;
	
	// AVCapture and UIDevice have opposite meanings for landscape left and right (AVCapture orientation is the same as UIInterfaceOrientation)
	else if (deviceOrientation == UIDeviceOrientationLandscapeLeft)
		orientation = AVCaptureVideoOrientationLandscapeRight;
	else if (deviceOrientation == UIDeviceOrientationLandscapeRight)
		orientation = AVCaptureVideoOrientationLandscapeLeft;
	
	// Ignore device orientations for which there is no corresponding still image orientation (e.g. UIDeviceOrientationFaceUp)
}

// Find a camera with the specificed AVCaptureDevicePosition, returning nil if one is not found
- (AVCaptureDevice *) cameraWithPosition:(AVCaptureDevicePosition) position
{
    NSArray *devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    for (AVCaptureDevice *device in devices) {
        if ([device position] == position) {
            return device;
        }
    }
    return nil;
}

// Find a back facing camera, returning nil if one is not found
- (AVCaptureDevice *) backFacingCamera
{
    return [self cameraWithPosition:AVCaptureDevicePositionBack];
}


@end

#pragma mark -
@implementation AVCamCaptureManager (RecorderDelegate)

@end
