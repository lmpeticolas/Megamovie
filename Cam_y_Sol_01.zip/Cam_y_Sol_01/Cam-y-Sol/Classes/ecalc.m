//
//  main.c
//  Eclipse
//
//  Created by A B on 9/23/12.

// The code in this file is a port of JavaScript Code originally released
// With the copyright notice shown below.
// A combined work including the code is subject to its terms.

// Other files in this XCode project are deemed separate, and released under
// an MIT style license, shown below. A user combining files into a single work
// for release is likely required to release all files under a GPL license (v2 or later).
// Seek legal advice if unsure about your rights when using these files.

// Eclipse Calculator
//
// This code is being released under the terms of the GNU General Public
// License (http://www.gnu.org/copyleft/gpl.html) with the request that if
// you do improve on it or use it in your own site, please let me know at
// chris@obyrne.com  Thanks!
//
// http://www.chris.obyrne.com/
//

/*
 Javascript Eclipse Calculator
 Copyright (C) 2003 Chris O'Byrne and Stephen McCann
 
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 */

/*
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 
 Copyright (C) Adrian Buriks 2012
 */

// Stupid implementation
// Passed location and date, will scan through all later eclipes to and stop at first one you could see.

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "ecalc_data.h"
#include "ctype.h"


// TEST CASE WILL BE...

//Eclipse will be 2011/Jan/04 (P) Julian date =

//2011/Jan/04
// Just a bit before the time.
//2455565.8692

//35,36, 1 = LAT N
// 37,38, -1 = LON S
// 15 = ALT
// 0,0,-1,0 = Hr, Min, E, Winter time 



//
// Populate the circumstances array with the time-only dependent circumstances (x, y, d, m, ...);
double * timedependent(double circumstances[]) {
    double t, ans;
    int index;
    int type;
    double ftype;
    
    t = circumstances[1];    
    index = (int)((float)(floor( obsvconst[6])));
    
    // Calculate x
    ans = eclipse_db[9+index] * t + eclipse_db[8+index];
    ans = ans * t + eclipse_db[7+index];
    ans = ans * t + eclipse_db[6+index];
    circumstances[2] = ans;
    
    // Calculate dx
    ans = 3.0 * eclipse_db[9+index] * t + 2.0 * eclipse_db[8+index];
    ans = ans * t + eclipse_db[7+index];
    circumstances[10] = ans;
    
    // Calculate y
    ans = eclipse_db[13+index] * t + eclipse_db[12+index];
    ans = ans * t + eclipse_db[11+index];
    ans = ans * t + eclipse_db[10+index];
    circumstances[3] = ans;
    
    // Calculate dy
    ans = 3.0 * eclipse_db[13+index] * t + 2.0 * eclipse_db[12+index];
    ans = ans * t + eclipse_db[11+index];
    circumstances[11] = ans;
    
    // Calculate d
    ans = eclipse_db[16+index] * t + eclipse_db[15+index];
    ans = ans * t + eclipse_db[14+index];
    ans = ans * PI / 180.0;
    circumstances[4] = ans;
    
    // sin d and cos d
    circumstances[5] = sin(ans);
    circumstances[6] = cos(ans);
    
    // Calculate dd
    ans = 2.0 * eclipse_db[16+index] * t + eclipse_db[15+index];
    ans = ans * PI / 180.0;
    circumstances[12] = ans;
    
    // Calculate m
    ans = eclipse_db[19+index] * t + eclipse_db[18+index];
    ans = ans * t + eclipse_db[17+index];
    if (ans >= 360.0) {
        ans = ans - 360.0;
    };
    ans = ans * PI / 180.0;
    circumstances[7] = ans;
    
    // Calculate dm
    ans = 2.0 * eclipse_db[19+index] * t + eclipse_db[18+index];
    ans = ans * PI / 180.0;
    circumstances[13] = ans;
    
    // Convert type to an int for later use
    ftype = circumstances[0];
    if (ftype < -1.5)
        type = -2;
    else if (ftype < -.5)
        type = -1;
    else if (ftype < .5)
        type = 0;
    else if (ftype < 1.5)
        type = 1;
    else //if (ftype < 2.5)
        type = 2;
        
    // Calculate l1 and dl1
    if ((-2 == type) || (0 == type) || (2 == type)) {
        ans = eclipse_db[22+index] * t + eclipse_db[21+index];
        ans = ans * t + eclipse_db[20+index];
        circumstances[8] = ans;
        circumstances[14] = 2.0 * eclipse_db[22+index] * t + eclipse_db[21+index];
    };
    
    // Calculate l2 and dl2
    if ((type == -1) || (type == 0) || (type == 1)) {
        ans = eclipse_db[25+index] * t + eclipse_db[24+index];
        ans = ans * t + eclipse_db[23+index];
        circumstances[9] = ans;
        circumstances[15] = 2.0 * eclipse_db[25+index] * t + eclipse_db[24+index];
    };
    
    return circumstances;
};

//
// Populate the circumstances array with the time and location dependent circumstances
double * timelocdependent(double circumstances[]) {
//    double ans;
    double type;
    int index;
    
    timedependent(circumstances);
    index = (int) ((float) floor(obsvconst[6]));
    // Calculate h, sin h, cos h
    circumstances[16] = circumstances[7] - obsvconst[1] - (eclipse_db[index+5] / 13713.44);
    circumstances[17] = sin(circumstances[16]);
    circumstances[18] = cos(circumstances[16]);
    // Calculate xi
    circumstances[19] = obsvconst[5] * circumstances[17];
    // Calculate eta
    circumstances[20] = obsvconst[4] * circumstances[6] - obsvconst[5] * circumstances[18] * circumstances[5];
    // Calculate zeta
    circumstances[21] = obsvconst[4] * circumstances[5] + obsvconst[5] * circumstances[18] * circumstances[6];
    // Calculate dxi
    circumstances[22] = circumstances[13] * obsvconst[5] * circumstances[18];
    // Calculate delta (deta?)
    circumstances[23] = circumstances[13] * circumstances[19] * circumstances[5] - circumstances[21] * circumstances[12];
    // Calculate u
    circumstances[24] = circumstances[2] - circumstances[19];
    // Calculate v
    circumstances[25] = circumstances[3] - circumstances[20];
    // Calculate a
    circumstances[26] = circumstances[10] - circumstances[22];
    // Calculate b
    circumstances[27] = circumstances[11] - circumstances[23];
    // Calculate l1'
    
    // Convert type to an int for later use
    double ftype = circumstances[0];
    if (ftype < -1.5)
        type = -2;
    else if (ftype < -.5)
        type = -1;
    else if (ftype < .5)
        type = 0;
    else if (ftype < 1.5)
        type = 1;
    else //if (ftype < 2.5)
        type = 2;
    if ((type == -2) || (type == 0) || (type == 2)) {
        circumstances[28] = circumstances[8] - circumstances[21] * eclipse_db[26+index];
    };
    // Calculate l2'
    if ((type == -1) || (type == 0) || (type == 1)) {
        circumstances[29] = circumstances[9] - circumstances[21] * eclipse_db[27+index];
    };
    // Calculate n^2
    circumstances[30] = circumstances[26] * circumstances[26] + circumstances[27] * circumstances[27];
    return circumstances;
};

//
// Iterate on C1 or C4
double * c1c4iterate(double circumstances[]) {
    double sign;
    double tmp;
    double n;
    int iter;
    
    timelocdependent(circumstances);
    
    // Convert type to an int for later use
    double ftype = circumstances[0];
    int type;
    
    if (ftype < -1.5)
        type = -2;
    else if (ftype < -.5)
        type = -1;
    else if (ftype < .5)
        type = 0;
    else if (ftype < 1.5)
        type = 1;
    else// if (ftype < 2.5)
        type = 2;
    
    if (type < 0) {
        sign=-1.0;
    } else {;
        sign=1.0;
    };
    tmp=1.0;
    iter=0;
    while (((tmp > 0.000001) || (tmp < -0.000001)) && (iter < 50)) {
        n = sqrt(circumstances[30]);
        tmp = circumstances[26] * circumstances[25] - circumstances[24] * circumstances[27];
        tmp = tmp / n / circumstances[28];
        tmp = sign * sqrt(1.0 - tmp * tmp) * circumstances[28] / n;
        tmp = (circumstances[24] * circumstances[26] + circumstances[25] * circumstances[27]) / circumstances[30] - tmp;
        circumstances[1] = circumstances[1] - tmp;
        timelocdependent(circumstances);
        iter++;
    };
    return circumstances;
};

//---
//
// Get C1 and C4 data
//   Entry conditions -
//   1. The mid array must be populated
//   2. The magnitude at mid eclipse must be > 0.0
void getc1c4() {
    double tmp;
    double n;
    
    n = sqrt(mid[30]);
    tmp = mid[26] * mid[25] - mid[24] * mid[27];
    tmp = tmp / n / mid[28];
    tmp = sqrt(1.0 - tmp * tmp) * mid[28] / n;
    c1[0] = -2.0;
    c4[0] = 2.0;
    c1[1] = mid[1] - tmp;
    c4[1] = mid[1] + tmp;
    c1c4iterate(c1);
    c1c4iterate(c4);
};

//;
// Iterate on C2 or C3;
double * c2c3iterate(double circumstances[]) {;
    double sign;
    int iter;
    double tmp;
    double n;
    
    timelocdependent(circumstances);
    // Convert type to an int for later use
    double ftype = circumstances[0];
    int type;
    
    if (ftype < -1.5)
        type = -2;
    else if (ftype < -.5)
        type = -1;
    else if (ftype < .5)
        type = 0;
    else if (ftype < 1.5)
        type = 1;
    else // if (ftype < 2.5)
        type = 2;
    
    if (type < 0) {;
        sign=-1.0;
    } else {;
        sign=1.0;
    };
    if (mid[29] < 0.0) {
        sign = -sign;
    };
    tmp=1.0;
    iter=0;
    while (((tmp > 0.000001) || (tmp < -0.000001)) && (iter < 50)) {
        n = sqrt(circumstances[30]);
        tmp = circumstances[26] * circumstances[25] - circumstances[24] * circumstances[27];
        tmp = tmp / n / circumstances[29];
        tmp = sign * sqrt(1.0 - tmp * tmp) * circumstances[29] / n;
        tmp = (circumstances[24] * circumstances[26] + circumstances[25] * circumstances[27]) / circumstances[30] - tmp;
        circumstances[1] = circumstances[1] - tmp;
        timelocdependent(circumstances);
        iter++;
    };
    return circumstances;
};

//;
// Get C2 and C3 data
//   Entry conditions -
//   1. The mid array must be populated
//   2. There mut be either a total or annular eclipse at the location!
void getc2c3() {
    double tmp;
    double n;
    
    n = sqrt(mid[30]);
    tmp = mid[26] * mid[25] - mid[24] * mid[27];
    tmp = tmp / n / mid[29];
    tmp = sqrt(1.0 - tmp * tmp) * mid[29] / n;
    c2[0] = -1.0;
    c3[0] = 1.0;
    if (mid[29] < 0.0) {
        c2[1] = mid[1] + tmp;
        c3[1] = mid[1] - tmp;
    } else {;
        c2[1] = mid[1] - tmp;
        c3[1] = mid[1] + tmp;
    };
    c2c3iterate(c2);
    c2c3iterate(c3);
};

//
// Get the observational circumstances
void observational(double circumstances[]) {
    double contacttype;
    double coslat;
    double sinlat;
    
    // We are looking at an "external" contact UNLESS this is a total eclipse AND we are looking at;
    // c2 or c3, in which case it is an INTERNAL contact! Note that if we are looking at mid eclipse,;
    // then we may not have determined the type of eclipse (mid[39]) just yet!;
    
    // Convert type to an int for later use
    double ftype = circumstances[0];
    int type;
    
    if (ftype < -1.5)
        type = -2;
    else if (ftype < -.5)
        type = -1;
    else if (ftype < .5)
        type = 0;
    else if (ftype < 1.5)
        type = 1;
    else //if (ftype < 2.5)
        type = 2;
    
    if (0 == type) {
        contacttype = 1.0;
    } else {
        if ((3 == mid[39]) && ((-1 == type) || (1 == type))) {
            contacttype = -1.0;
        } else {
            contacttype = 1.0;
        };
    };
    
    // Calculate p
    circumstances[31] = atan2(contacttype*circumstances[24], contacttype*circumstances[25]);
    // Calculate alt
    sinlat = sin(obsvconst[0]);
    coslat = cos(obsvconst[0]);
    circumstances[32] = asin(circumstances[5] * sinlat + circumstances[6] * coslat * circumstances[18]);
    // Calculate q
    circumstances[33] = asin(coslat * circumstances[17] / cos(circumstances[32]));
    if (circumstances[20] < 0.0) {
        circumstances[33] = PI - circumstances[33];
    };
    // Calculate v
    circumstances[34] = circumstances[31] - circumstances[33];
    // Calculate azi
    circumstances[35] = atan2(-1.0*circumstances[17]*circumstances[6], circumstances[5]*coslat - circumstances[18]*sinlat*circumstances[6]);
};

//
// Calculate mid eclipse
void getmid() {
    int iter;
    double tmp;
    
    mid[0] = 0.0; // Remember, this serves as an int.
    mid[1] = 0.0;
    
    
    iter = 0;
    tmp = 1.0;
    timelocdependent(mid);
    while (((tmp > 0.000001) || (tmp < -0.000001)) && (iter < 50)) {;
        tmp = (mid[24] * mid[26] + mid[25] * mid[27]) / mid[30];
        mid[1] = mid[1] - tmp;
        iter++;
        timelocdependent(mid);
    };
};

//
// Populate the c1, c2, mid, c3 and c4 arrays;
// These are the output arrays.

void getall() {
    
    getmid();
    observational(mid);
    // Calculate m, magnitude and moon/sun;
    mid[36] = sqrt(mid[24]*mid[24] + mid[25]*mid[25]);
    mid[37] = (mid[28] - mid[36]) / (mid[28] + mid[29]);
    mid[38] = (mid[28] - mid[29]) / (mid[28] + mid[29]);
    
    if (mid[37] > 0.0) {
        getc1c4();
        if ((mid[36] < mid[29]) || (mid[36] < -mid[29])) {;
            getc2c3();
            if (mid[29] < 0.0) {
                mid[39] = 3.0; // Total eclipse
            } else {
                mid[39] = 2.0; // Annular eclipse
            }
            observational(c2);
            observational(c3);
            
            
/*          
            //AAB Need to map this to an input from the form
            // This is to patch a bug with 2003 information. We don't care about 2003, as it is past.
            // In theory we can simply get rid of this!
            // 2003 May 31 eclipse limb corrections -
            if (parseInt(document.eclipseform.index.options[document.eclipseform.index.selectedIndex].value) == 8) {
                c2[36] = limbcorrection(c2[31], C2limb2003May);
                c3[36] = limbcorrection(c3[31], C3limb2003May);
                if (c2[36] < 990.0) {;
                    c2[1] += c2[36] / 3600.0;
                };
                if (c3[36] < 990.0) {;
                    c3[1] += c3[36] / 3600.0;
                };
            } else {
*/
                c2[36] = 999.9;
                c3[36] = 999.9;
    
//            };

        } else {;
            mid[39] = 1; // Partial eclipse
        };
        observational(c1);
        observational(c4);
    } else {
        mid[39] = 0.0; // No eclipse
    };
};


//
// Get the local date string of an event
// AAB: NOTE: ANS appears to be a string
// a and d need to be converted to strings and concatenated (apparently)
// date_in is a buffer to hold the output
char * loc_getdate(double circumstances[], char ans[]) {
    
    // ans is presumably an empty buffer
    
    double t;

    
    int jd, c,d,e;
    
    int index;
    
    index = (int) ((float) floor(obsvconst[6])); // The entry in the elements table with info about eclipse
    
    // Calculate the local time. Add 0.05 seconds, as we will be rounding up to the nearest 0.1 sec
    // t is a difference in days. A floating point number
    t = circumstances[1] + eclipse_db[1+index] - obsvconst[3] - (eclipse_db[4+index] - 0.05) / 3600.0;  // Divide by 3600 = hours*seconds -> time in hours
    if (t < 0.0) {
        t = t + 24.0;
    }
    if (t >= 24.0) {
        t = t - 24.0;
    }
    
    // Calculate the Julian Date (JD) for as close to local noon as possible, and convert into a date 
    // This algorithm will only work for the period 1900/03/01 to 2100/02/28
    jd = floor(eclipse_db[index] - (t/24.0) + 1538.0);
    
    c = floor((jd-122.1)/365.25); // Calendar year
    
    d = floor(365.25*c); 
    e = floor((jd - d) / 30.6001); // month
    d = jd - d - floor(30.6001*e); // day
    
    if (e < 13.5) {
        e = e - 1;
    } else {
        e = e - 13;
    }

    // Fill the date string
    ans[0] = '\0';

    // Print the year
    if (e > 2.5) {
        sprintf(tmpstr,"%02d/",(c-4716));  
        strcat(ans,tmpstr);
    } else {
        sprintf(tmpstr,"%02d/",(c-4715));
        strcat(ans,tmpstr);
    }
    
    // Print the month
    sprintf(tmpstr,"%02d/",e);
    strcat(ans,tmpstr);
    
    // Print the day
    sprintf(tmpstr,"%02d",d);
    strcat(ans,tmpstr);
    
    return ans;
}


//
// Get the local time string of an event
char* gettime(double circumstances[],char ans[]) {
    
    double  t;
    int index;
    

    index = (int) ((float) floor(obsvconst[6]));
    
    // Calculate the local time. Add 0.05 seconds, as we will be rounding up to the nearest 0.1 sec
    t = circumstances[1] + eclipse_db[1+index] - obsvconst[3] - (eclipse_db[4+index] - 0.05) / 3600.0;
    
    if (t < 0.0) {
        t = t + 24.0;
    };
    if (t >= 24.0) {;
        t = t - 24.0;
    };
    
    // Create the time string
    ans[0] = '\0';
    
    // Print the hours and remove
    sprintf(tmpstr,"%02d:",(int)((float) floor(t)));
    strcat(ans,tmpstr);
    t = (t * 60.0) - 60.0 * floor(t);
 
    // Print the minutes and remove
    sprintf(tmpstr,"%02d:",(int)((float) floor(t)));
    strcat(ans,tmpstr);    
    t = (t * 60.0) - 60.0 * floor(t);

    // Print the seconds
    sprintf(tmpstr, "%02d.",(int)((float) floor(t)));
    strcat(ans,tmpstr);
    
    // Print the 1/10th of seconds
    sprintf(tmpstr,"%1d",(int)((float) floor(10.0 * (t - floor(t)))));
    strcat(ans,tmpstr);
    
    // Add an asterisk if the altitude is less than zero
    if (circumstances[32] <= 0.0) {
        strcat(ans,"*");
    };
    
    return ans;
};


//
// Get the duration in mm:ss.s format;
//
// Adapted from code written by Stephen McCann - 27/04/2001;
char * getduration(char ans[]) {
    double tmp;
    
    tmp=c3[1]-c2[1];
    if (tmp<0.0) {
        tmp=tmp+24.0;
    } else if (tmp >= 24.0) {;
        tmp=tmp-24.0;
    };
    tmp=(tmp*60.0)-60.0*floor(tmp)+0.05/60.0;
    
    // Format the output
    ans[0] = '\0';
    
    // Get the mm and remove
    sprintf(tmpstr, "%02d:",(int)((float) floor(tmp)));
    strcat(ans,tmpstr);
    tmp = (tmp*60.0)-60.0*floor(tmp);
    
    // Get the seconds
    sprintf(tmpstr,"%02d.",(int)((float) floor(tmp)));
    strcat(ans,tmpstr);
    
    //Get the 1/10 sec
    sprintf(tmpstr,"%1d",(int)(float) (floor((tmp-floor(tmp))*10.0)));
    
    return ans;
};


void displayc1c4() {
    loc_getdate(c1,c1_date_str);
    gettime(c1,c1_time_str);
    loc_getdate(c4,c4_date_str);
    gettime(c4,c4_time_str);
}


//
// Display the information about 2nd and 3rd contact
void displayc2c3() {
    loc_getdate(c2,c2_date_str);
    gettime(c2,c2_time_str);
    loc_getdate(c3,c3_date_str);
    gettime(c3,c3_time_str);
}


void displaymid() {
    loc_getdate(mid,mid_date_str);
    gettime(mid,mid_time_str);
}

//
// Re-calculate
void recalculate() {
    
    //clearresults(); // clear the text string
    //readform();     // Get the input from the form
    
    getall();
    displaymid();   // Calculate the mid point data

   
    // 0 = none, 1 = partial, 2 = annular, 3 = total
    double ftype = mid[39];
    int type;
    
    if (ftype < .5)
        type = 0;
    else if (ftype < 1.5)
        type = 1;
    else if (ftype < 2.5)
        type = 2;
    else //if (ftype < 3.5)
        type = 3;
    
    // Is there an event?
    if (type > 0) {
        displayc1c4();
        
        // Convert to int.
        ftype = mid[39];
        if (ftype < .5)
            type = 0;
        else if (ftype < 1.5)
            type = 1;
        else if (ftype < 2.5)
            type = 2;
        else if (ftype < 3.5)
            type = 3;

        // Is there a total/annular event?
        if (type > 1) {
            displayc2c3();
            // Is the sun below the horizon for the entire duration of the event?;
            if ((c1[32] <= 0.0) && (c4[32] <= 0.0)) {
                strcpy(duration_str,"n/a");
                // ... or is the sun above the horizon for at least some of the event?;
            } else {
                // Is the sun below the horizon for just the total/annular event?;
                if ((c2[32] <= 0.0) && (c3[32] <= 0.0)) {
                    strcpy(duration_str,"n/a");
                    // ... or is the sun above the horizon for at least some of the total/annular event?;
                } else {
                    // Is it an annular event?
                    
                    // Convert to int.
                    ftype = mid[39];
                    if (ftype < .5)
                        type = 0;
                    else if (ftype < 1.5)
                        type = 1;
                    else if (ftype < 2.5)
                        type = 2;
                    else //if (ftype < 3.5)
                        type = 3;
                    
                    // Is the sun above the horizon for the entire annular/total event?;
                    if ((c2[32] > 0.0) && (c3[32] > 0.0)) {
                        getduration(duration_str);
                        // ... or is the sun below the horizon for at least some of the annular/total event;
                    } else {
                        strcpy(duration_str,"???");
                        
                        //document.eclipseform.duration.value = "???";
                    
                    };
                };
            };
            // ... or is it just a partial event?;
        } else {
            strcpy(duration_str,"n/a");
            strcpy(c2_date_str,"== None ==");
            strcpy(c3_date_str,"== None ==");
        };
        // ... or is there no event at all?;
    } else {
        strcpy(duration_str, "n/a");
        strcpy(c1_date_str,"== None ==");
        strcpy(c2_date_str, "== None ==");
        strcpy(c3_date_str,"== None ==");
        strcpy(c4_date_str,"== None ==");
    };
};



#define NUM_ELEMENTS (sizeof(eclipse_db) / sizeof(double) / 28)

double Greg2Julian(int monthGreg, int dayGreg, int yearGreg) {
    if (monthGreg <= 2) {
        monthGreg += 12;
        yearGreg -= 1;
    }
    double A = floor(((double) yearGreg) / 100.0);
    double B = 2 - A + floor(A / 4.0);
    double julDate = floor(365.25*(yearGreg+4716)) + floor(30.6001*(monthGreg+1)) + dayGreg + B - 1524.5;
    
    return julDate;
}

// We note that c1_date_str, c1_time_str, c4_date_str, and c4_time_str are all we need.
// NOTE: Issue - People may put in dates before table starts.

int calc_eclipse(double latitude,  // +N, -S (this is the same as iphone provides)
                 double longitude, // +W, -E (this is reverse of what iPhone provides)
    
                 // This is today's gregorian date (GMT).
                 // It has no DST correction, etc.
                 // The output will be corrected for local situation and time zone.
                 
                 
                 // These are the current system date...but, they magically get converted to it seems?
                 
                 int month, // 1 - 12
                 int day,   // date of month
                 int year,  // 4 digit year (I guess)
                 int hour,  // This is the current time at our location
                 int min,   // It is used in the final step to determine whether 
                 int sec   // we are past the eclipse.
                            // If so, a match at the current day is ruled out,
                            // and the search continues until the next eclipse.
                            // This is to fix the issue that after an eclipse,
                            // we continue to count negatively.
                 
                 // This is the amount that would need to be added to get the current time. 
 //                int offsetSecondsGMTInput  // No longer used
                
                 // This is the number of seconds offset from GMT
                                            // in seconds at the current location.
                                            // Due to daylight savings time, it may be
                                            // different than on the day of the eclipse.
                                            // If it is, then the time used to determine if
                                            // we are past a particular eclipse on the same
                                            // day must be adjusted by this amount prior to
                                            // end time comparison.
                 
                 // NOTE: We don't want to get GMT, and convert.
                 // The reason is, we could get the wrong day.
                 // However, if an eclipse is visible, we're not near midnight.
                 // Thus, we can simply add or subtract the hour as needed.
                  
                 // The time zone will need to be calculated using longitude and latitude.
                 // This can be added or subtracted later.
                  
                 // The current offset from GMT
//                 int tz_hr,    // 1 - 14              
//                 int tz_min /*, */   // (0, 15, 30, 45)
                 
                 // No longer used
                 //int tz_direction, // -1, 1 (-1 = +GMT, 1 = -GMT
                 
                  
                // Here, we will always pass a 0. This will be adjusted using Adrian API's later.
                //int dl_savings    // 0 = Winter, 1 = summer
                     // Will always be called with 0, and adjusted afterwards

                 )
{
    int index;
    int i;
    
    unsigned long lenstr1;  // Used for temporary lengths of C1_...str and C4_...str info.
    unsigned long lenstr4;
    
    
    int yyyy;
    int mm_month;
    int dd;
    int hh;
    int mm_min;
    int ss;
    

    eclipseError = 0;
    
    if ((year < 2012) || (year > 2035)){
      
        // Current date is outside range 2012-2035 Error
        eclipseError = 1;
        return eclipseError;
        
    };
    

    // This will be freed at the end of this routine, or if we return due to an error.
    
    // Set up the components as GMT
    NSDateComponents *components = [[NSDateComponents alloc] init];
    [components setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
    
    // Read the components
    NSCalendar *greg = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];    
    
    [components setYear:year];
    [components setMonth:month];
    [components setDay:day];
    [components setHour:hour];
    [components setMinute:min];
    [components setSecond:sec];
    
    // Compute the gregorian (GMT) at our current location.
    NSDate *inputDateGMT = [greg dateFromComponents:components];
    
 //   NSDate *currentDate = [NSDate date];

    double julian_date = Greg2Julian(month,day,year);
    
    // HACK! Move the search time back 4 hours.
    // We now wish to move the search date back a few hours.
    // This assures we don't skip past the current eclipse
    // while camera is taking pictures.
    
    julian_date -= (double) 24.0 / 6.0;
    
    
    obsvconst[0] = (double) latitude * (PI / 180.0);
    
    //latx * (latd + latm / 60.0) * (PI / 180.0); // Input latitude
    
    obsvconst[1] = (double) longitude * (PI / 180.0);
    //lonx * (lond + lonm / 60.0) * (PI / 180.0); // Input longitude
    
//    double alt = atof(argv[8]); // alt
    // Always use altitude of 0
    obsvconst[2] = 0.0; //alt; // Input altitude
 
    obsvconst[3] = 0.0; //tzx * (tzh + tzm / 60.0) - dst; //Time offset
    
    // Geocentric position
    double tmp = atan(0.99664719*tan(obsvconst[0]));
    obsvconst[4] = 0.99664719*sin(tmp)+(obsvconst[2]/6378140.0)*sin(obsvconst[0]); // sin and cos
    obsvconst[5] = cos(tmp)+(obsvconst[2]/6378140.0*cos(obsvconst[0]));
    
    index = 28 * (NUM_ELEMENTS - 1);    
    for (i = (NUM_ELEMENTS -1); i > 0; --i)
    {  
        if (julian_date > eclipse_db[index]) break;
        index -= 28;
    };
    
    obsvconst[6] = (float) index + .01;
    
    // NOTE: this is a global variable
    is_eclipse_visible = false;
    // index is the first eclipse in the table that occurs after the current date.
    // For each later eclipse, we must now determine if we can see it.
    for (; i < NUM_ELEMENTS; ++i)
    {
        // Call the calulation function
        // If there is visible data...that's the next eclipse to show
        obsvconst[6] += 28.0;
        
        // Clear the output arrays
        // What we know....
        
        // Start and end are not that accurate right now.
        // Only about 2 minutes of total darkness.
        // If there's an * you can't see it (may be in other part of the world)
        
        // If there is not an * in all fields, then do the whole period.        
        
        // What else:
        
        memset(c1,0,sizeof(c1));
        memset(c2,0,sizeof(c2));
        memset(mid,0,sizeof(mid));
        memset(c3,0,sizeof(c3));
        memset(c4,0,sizeof(c4));
        
        recalculate();
        
        // If we found an eclipse of some sort.
        if ((c1[39] > 0.5) || (c2[0] > 0.5) || (mid[0] > 0.5) || (c3[0] > 0.5) || (c4[0] > 0.5))
        { 
            
            // Check strings output in detail
            lenstr1 = strlen(c1_date_str);
            lenstr4 = strlen(c4_date_str);
            
            // Do we have numbers for last position of the dates -> May have a visible eclipse
            if (
                (isdigit(c1_date_str[lenstr1 - 1])) && 
                (isdigit(c4_date_str[lenstr4 - 1])))
            {
                
                lenstr1 = strlen(c1_time_str);
                lenstr4 = strlen(c4_time_str);
                
                // Do we have at least one time that is not below the horizon?
                if (isdigit(c1_time_str[lenstr1 - 1]) || 
                    isdigit(c4_time_str[lenstr4 - 1])){
                    
                    // We have some amount of eclipse visible.
                    strcpy(eclipse_start_date_str, c1_date_str);
                    strcpy(eclipse_start_time_str, c1_time_str);
                    strcpy(eclipse_mid_date_str, mid_date_str);
                    strcpy(eclipse_mid_time_str, mid_time_str);
                    strcpy(eclipse_end_date_str, c4_date_str);
                    strcpy(eclipse_end_time_str, c4_time_str);

                    ////////////////////////////////////////////////
                    
                    // Remove non-digit * at end if present
                    if (!isdigit(eclipse_start_time_str[lenstr1 - 1]))
                        eclipse_start_time_str[lenstr1 - 1] = '\0';
                    
                    // Remove non-digit * at edn if present
                    if (!isdigit(eclipse_mid_time_str[lenstr1 - 1]))
                        eclipse_mid_time_str[lenstr1 - 1] = '\0';
                    
                    
                    // Remove non-digit * at end if present
                    if (!isdigit(eclipse_end_time_str[lenstr4 - 1]))
                        eclipse_start_time_str[lenstr4 - 1] = '\0';
                    
                    //////////////////////////////////////////////////////////////////////
                    // We now adjust for time zone and DST on the eclipse date.
                    
                
                    // There is one particularly unpleasant possibility this doesn't handle.
                    // What if at a certain location, the ecliipse falls on the day of the time change to DST,
                    // and in the 2 hour window when the same time occurs twice?

                    // For example, when a clock is set backward, it means the same hour occurs twice.
                    // We go from 1am - 2am, then set back, and it happens again on the same date.
                    
                    // Is this possible?
                    // Certainly not in Australia...but perhaps in Alaska?
                
                    // For the moment, we will assume this doesn't occur.
                    // Will need to check this later.
                
                    // First we test against the end date

                    // The GMT version calculated
                    yyyy        = atoi(&eclipse_end_date_str[0]);
                    mm_month    = atoi(&eclipse_end_date_str[5]);
                    dd          = atoi(&eclipse_end_date_str[8]);
                    hh          = atoi(&eclipse_end_time_str[0]);
                    mm_min      = atoi(&eclipse_end_time_str[3]);
                    ss          = atoi(&eclipse_end_time_str[6]);
                    
                    [components setDay:dd];
                    [components setMonth:mm_month];
                    [components setYear:yyyy];
                    [components setHour:hh];
                    [components setMinute:mm_min];
                    [components setSecond:ss];
                    
                    // GMT version of the date
                    NSDate *eclipse_end_date_GMT = [greg dateFromComponents:components];

                    // Check if we may have more work to do.
                    // We will say it's visible up to 15 minutes after the end of the Eclipse.
                    // After that, it's necessary to recalculate.
                    if ( [inputDateGMT timeIntervalSinceDate:eclipse_end_date_GMT] <= (15 * 60))
                    {
                    
                    NSInteger offsetSecondsOnDate = [[NSTimeZone systemTimeZone] secondsFromGMTForDate:eclipse_end_date_GMT];
                    NSDate *eclipse_end_date_corrected = [eclipse_end_date_GMT dateByAddingTimeInterval:offsetSecondsOnDate];
                    
                    // The GMT version calculated by system for start date
                    yyyy        = atoi(&eclipse_start_date_str[0]);
                    mm_month    = atoi(&eclipse_start_date_str[5]);
                    dd          = atoi(&eclipse_start_date_str[8]);
                    hh          = atoi(&eclipse_start_time_str[0]);
                    mm_min      = atoi(&eclipse_start_time_str[3]);
                    ss          = atoi(&eclipse_start_time_str[6]);

                    
                    [components setYear:yyyy];
                    [components setMonth:mm_month];
                    [components setDay:dd];
                    [components setHour:hh];
                    [components setMinute:mm_min];
                    [components setSecond:ss];
                    
                    // Localize the start date
                    NSDate *eclipse_start_date_GMT = [greg dateFromComponents:components];
                    offsetSecondsOnDate = [[NSTimeZone systemTimeZone] secondsFromGMTForDate:eclipse_start_date_GMT];
                    NSDate *eclipse_start_date_corrected = [eclipse_start_date_GMT dateByAddingTimeInterval:offsetSecondsOnDate];
                    
                        
                    // Now do the middle
                        
                    // The GMT version calculated by system for mid date
                    yyyy        = atoi(&eclipse_mid_date_str[0]);
                    mm_month    = atoi(&eclipse_mid_date_str[5]);
                    dd          = atoi(&eclipse_mid_date_str[8]);
                    hh          = atoi(&eclipse_mid_time_str[0]);
                    mm_min      = atoi(&eclipse_mid_time_str[3]);
                    ss          = atoi(&eclipse_mid_time_str[6]);
                    
                    
                    [components setYear:yyyy];
                    [components setMonth:mm_month];
                    [components setDay:dd];
                    [components setHour:hh];
                    [components setMinute:mm_min];
                    [components setSecond:ss];
                    
                    // Localize the mid date
                    NSDate *eclipse_mid_date_GMT = [greg dateFromComponents:components];
                    offsetSecondsOnDate = [[NSTimeZone systemTimeZone] secondsFromGMTForDate:eclipse_mid_date_GMT];
                    NSDate *eclipse_mid_date_corrected = [eclipse_mid_date_GMT dateByAddingTimeInterval:offsetSecondsOnDate];
                    
                    is_eclipse_visible = true;
                    
                    // We now put the corrected dates back into the strings.
                    NSUInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit |NSSecondCalendarUnit;

                    // NOTE: I can see that the date has the right numbers at GMT.
                    //       The question is...how to get at those numbers!
                    
                    
                    NSTimeZone * tzGMT = [NSTimeZone timeZoneWithName:@"GMT"];
                    [greg setTimeZone:tzGMT];
                    
                    // Recover the dates and times we see
                    NSDateComponents * components_start = [greg components:unitFlags fromDate:eclipse_start_date_corrected];
//  already set as greg time zone set previously [components_start setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];

                    
                    int conv_year = [components_start year];
                    int conv_month = [components_start month];
                    int conv_day = [components_start day];
                    int conv_hour = [components_start hour];
                    int conv_min = [components_start minute];
                    int conv_sec = [components_start second];


                    // Local time at destination
                    sprintf(eclipse_start_date_str, "%04d/%02d/%02d",
                            conv_year,
                            conv_month,
                            conv_day);
                    
                    
                    sprintf(eclipse_start_time_str, "%02d:%02d:%02d",
                            conv_hour,
                            conv_min,
                            conv_sec);

                    NSDateComponents * components_mid = [greg components:unitFlags fromDate:eclipse_mid_date_corrected];
    
                        sprintf(eclipse_mid_date_str, "%04d/%02d/%02d",
                            [components_mid year],
                            [components_mid month],
                            [components_mid day]);
                        
                        
                        sprintf(eclipse_mid_time_str, "%02d:%02d:%02d",
                            [components_mid hour],
                            [components_mid minute],
                            [components_mid second]);
                        
                    // Local time at destination
                    
                    NSDateComponents * components_end = [greg components:unitFlags fromDate:eclipse_end_date_corrected];
// Already set since "greg" has right time zone     [components_end setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
                    
                    sprintf(eclipse_end_date_str, "%04d/%02d/%02d",
                            [components_end year],
                            [components_end month],
                            [components_end day]);
                    
                    
                    sprintf(eclipse_end_time_str, "%02d:%02d:%02d",
                            [components_end hour],
                            [components_end minute],
                            [components_end second]);
                    
                    break;
                        
                };
                    
            
            
            
            
            
            }
        }
        }
    }
    
 
#if 0
    if (false == is_eclipse_visible)
    {
        printf("No eclipse visible from this location between now and 2039.\n");
        //return 1;
    };
#endif
    
    // Tells start and end of next eclipse at this location (no additional details).

    //printEclipseInfo();
    
    // Original program
    // There are 6 inputs + index of eclipse
    //
    
    // We would need to get these from the device itself
    // 0 = North Latitude  (radians) Degrees, Minutes, -1, 1 = 3
    // 1 = West Longitude  (radians) Degrees, Minutes, -1, 1 = 3
    // 2 = Altitude = 2

    // Note: Can always get GMT on computer (I think) - So no need for time zone.
    // Will also need something to convert from Normal date -> Julian date [ For search through table ]
    //
    // Just count down in hours, min, sec
    // 3 = West time zone (hours) - This is for display - We'll just input 
    
    // 4 = rho sin 0'
    // 5 = rho cos 0'
    
    // 6 = a particular eclipse - This is for the data

    // insert code here...

//    return 0;
    
    
    [components release];
    [greg release];
    
    
    
    if (is_eclipse_visible)
    {
        return ECLIPSE_ERROR_NONE;
#if 0
        printf("Eclipse (start, end): %s %s, %s %s\n",
                eclipse_start_date_str,
                eclipse_start_time_str,
                eclipse_end_date_str,
                eclipse_end_time_str);
#endif
    }else
    {
        return ECLIPSE_ERROR_NO_ECLIPSE_VISIBLE;
        //printf("No Eclipse visible at your current location in the near future.\n");
    }
  }

// When calculating, the time at which an eclipse starts, the input must
// indicate the daylight savings time setting in the target location on the day of the
// eclipse. If we say it starts at 2pm on date X, that is what it means.
// 
// The countdown timer will need to count down to the GMT time in a sense.
// If the timezone is now different than when the eclipse will happen, that must be taken into account.
//
// It would be best to use an available Adrian API to caclulate the difference, perhaps.
// Although, these have screwed up in the past.
//
// Note: That this is the daylight savings time setting during the eclipse.
#if 0
int main(int argc, char * argv[])
{
    calc_eclipse(

                 /* Current location */
                 atof(argv[1]), // Lat  : positive for N, Negative for S
                 atof(argv[2]), // Long : positive for W, Negative for E
                 
                 /* Current Date */
                 atoi(argv[3]), // Month
                 atoi(argv[4]), // Day
                 atoi(argv[5]), // Year
                 
                 
                 atoi(argv[6]), // tz_hr        +GMT or -GMT
                 atoi(argv[7]), // tz_min       0,15,30,45  -- So far these have always been zero
                 
                 // No longer used
                 atoi(argv[8]), // tz_direction +GMT or -GMT
                 
                 // This is always 0 for current use
                 atoi(argv[9])  // dl_savings
                      );      
                 
                    
    return 0;                  
    
}
#endif