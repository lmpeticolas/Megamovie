//
//  UIImage+PhotoPicker.h
//
//  Copyright 2009 yourcompanyname. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIImage (PhotoPicker)

- (UIImage *)correctOrientation:(UIImage *)image;

@end
