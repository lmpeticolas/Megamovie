//
//  Configuration.h
//
//  Copyright 2009 yourcompanyname. All rights reserved.
//


// The main menu appears when this is defined.
#define FORCE_ENABLE_CAMERA

// If you cancel one source, don't return to main menu
// but return to other source.
// In our case, there is no other source...so we don't want this.
// #define SHOW_SOURCE_MENU_IF_DEFAULT_SOURCE_CANCELLED

#define UPLOAD_URL @"http://helio.cfa.harvard.edu/megamovie/upload.php"
#define CONTINUE_URL @"http://www.eclipsemegamovie.org/ThankYou.aspx"
