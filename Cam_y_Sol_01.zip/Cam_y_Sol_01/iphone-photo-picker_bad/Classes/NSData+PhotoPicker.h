//
//  NSData+PhotoPicker.h
//
//  Copyright 2009 yourcompanyname. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NSData (PhotoPicker)

+ (NSData *)utf8DataWithFormat:(NSString *)format, ...;

@end
